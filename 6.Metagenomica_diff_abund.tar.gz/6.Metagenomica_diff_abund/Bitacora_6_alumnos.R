#############################################################################
#########                          PASPE 2025                        ########
#########      Analisis de datos de Ciencias Genomicas usando R      ########
#########    E. Ernestina Godoy Lozano (elizabeth.godoy@insp.mx)     ########
#########                    Bitacora de comandos                    ########
#########                     UNIDAD 3. METAGENOMICA                 ########
#########                Analisis de abundancia diferencial          ########
#############################################################################
# Texto sin acentos


# 1. Cargar librerias de trabajo


# 2. Posicionarme en mi espacio de trabajo


# 3. Cargar datos para la sesion


# 4. checar cuantes muestras tenemos por clase


#########################################################
#### Pasos para generar la abundancia diferencial    ####
####            Metodo: metagenomeSeq                ####
#  1. Generar la comparacion pareada de los generos     #
#  diferencialmente abundantes de cada una de los       #
#  grupos que tenemos                                   #
#  2. Generar un directorio especial para que guarde    # 
#  toda la informacion de las permutaciones.            #
#  Ejemplo de como realizarlo con la funcion "system"   #
#  system("mkdir tablas/diff_abund")                    #
#  4. Extraer las dos condiciones                       #
#  5. Normalizar cada matriz                            #
#  6. Aplicar el modelo                                 #
#  7. Guardar los datos                                 #
#########################################################

# 5. Cambiarnos de directorio


#Verificar que si estamos en el directorio diff_abund


# 6. Juntar todos los resultados de OTUS_diff.txt


# 7. Sacar el numero de combinaciones


# 8. Unir las tablas de las combinaciones


# 9. Escribir tabla de todos los resultados


# 10. Generar un filtro de p ajustado a < 0.01 y <0.05


# 10.1 filtro <0.05


# 10.1 filtro <0.01


# 10.1 Escribir tablas


# 11. Quedemosnos con los generos que cambian en las 3 condiciones


# 12. generar tabla de logfold change


# 13. Extraer la informacion de la frecuencia relativa de los generos


# 13.1 Leer abundancias


# 13.2 Extraer solo los generos de interes


# 13.3 Generar una tabla de las medias de cada grupo de los generos de interes


# 13.4 Generar medias y DE para cada genero


# 13.5 Escribir tabla


# 14. Generar plot de logFC


# 14.1 Usemos geom_bar()


# 14.2 Guardar imagen


# 14.3 Otra propuesta con ggprub


### Listar objetos


### Informacion de la sesion


