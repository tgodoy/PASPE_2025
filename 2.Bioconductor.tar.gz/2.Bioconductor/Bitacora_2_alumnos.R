##############################################################################
#########                          PASPE 2025                        #########
#########      Analisis de datos de Ciencias Genomicas usando R      #########   
######       E. Ernestina Godoy Lozano (elizabeth.godoy@insp.mx)     #########
######                       Bitacora de comandos                    #########
######    UNIDAD 2. Bioconductor para analisis de secuencias cortas  #########
######          Secuencias, Alineamientos y Operaciones basicas      #########
##############################################################################

# Texto sin acentos

# Posicionarse en su directorio de trabajo


# Cargar librerias de trabajo


# visualizar las librerias que son dependencias de ShortRead


# Cargar funcion plotRanges()


#######################################################
###                       IRanges                   ###
###   Ejercicio 1. Generacion de objetos de IRanges  ##
#######################################################
# 1.1 Cargar libreria de trabajo


# 1.2 Generar objeto chr con funcion IRanges()


# 1.2 Tipo de objeto


# 1.3 Inicio del rango


# 1.4 Final del rango


# 1.5 ancho del rango


# 1.6 Podemos solo especificar el ancho del rango y el inicio, sin el termino del rango


# 1.8 Multiples rangos


# 1.9 Longitud de mi objeto chrs


# 1.10 Añadir nombres a los rangos usando "paste"


# 1.11 Generar grafico con plotRanges()


# 1.12 guardar la imagen con png()


#######################################################
###            Ejercicio 2. Subsets de rangos         #
#######################################################
# 2.1 Valores subsecuentes. Extraer los chrs de la posicion 2 a la 4


# 2.2 Valores salteados. Extraer los chrs 1, 6 y 3


#######################################################
###       Ejercicio 3. Manejo de objetos IRanges      #
#######################################################
# 3.1  Eliminar redundancia


# 3.2 Añadir o disminuir el ancho de los rangos con los operadores - y +


# 3.3 Desplazar los rangos por un factor 


# 3.4 Encontrar sobrelapamientos


# 3.5 Cobertura


# 3.6 Separacion de los rangos


# 3.7 Generar plot de disjoin


# 3.8 Guardar la imagen


# 3.9 Encontrar los gaps


# 3.10 Generar plot de gaps


# 3.11 Guardar la imagen con png


#######################################################
#####               GenomicRanges                     #
# Ejercicio 4. Generacion de objetos de GenomicRanges #
#######################################################
# 4.1 Cargar librerua GenomicRanges


# 4.2 Genrerar objeto gr con funcion GRanges()


# 4.3 Tipo de objeto


# 4.4 Añadir metadatos


# 4.5 Imprimir objeto gr


# 4.6 Usar plotRanges()


# 4.7 Acceder a los metadatos


# 4.8 Realizar operaciones con los metadatos


#######################################################
###    Ejercicio 5. Manejo de objetos GenomicRanges   #
#######################################################
# 5.1 Generar objeto gr2 con 3 chromosomas


# 5.2 Usar plotRanges()


# 5.3 Extraer nombres de las secuencias con "seqnames"


# 5.4 Rangos de las secuencias con "ranges"


# 5.5 Cadenas de las secuencias con "strand"


# 5.6 Otra manera de acceder a los metadatos con "$" (columnas extras) y "mcols"


# 5.7 Sobrelapamientos con "findOverlaps"


# 5.8 Generar un objeto GenomicRanges de un data frame


# Data frame


# Usar funcion makeGRangesFromDataFrame()


# Añadiendo la opcion keep.extra.columns


#######################################################
#####                  Biostrings                   ###
#Ejercicio 6. Creacion y manejo de objetos en Biostrings#
#######################################################
# 6.1 Cargar libreria Biostrings


# 6.2 Variables para generar secuencias al azar


# 6.3 Generacion de secuencia con la variable DNA_ALPHABET


# 6.4 Generacion de objeto DNAString


# 6.5 Frecuencia de las bases


# 6.5.1 Frecuencia absoluta


# 6.5.2 Frecuencia relativa


# 6.6 Longitud


# 6.7 Acceso a bases individuales. Obtener la base numero 4 de mi secuencia "seq"


# 6.8 Acceso a una parte de la secuencia; con un rango


#######################################################
#####                  Biostrings                   ###
####         Ejercicio 7. Transformaciones basicas    #
#######################################################
# 7.1 Reverso 


# 7.2 complemento


# 7.3 Reverso complementario


# 7.4 Traduccion


# 7.5 juntar las funciones


#######################################################
#####        Ejercicio 8. Subsets de secuencias      ##
#######################################################
# 8.1 Cargar libreria ShortRead


# 8.2 Crear un objeto de mas de una secuencia


# 8.3 Longitud de las secuencias en un objeto con mas de una secuencia


# 8.4 nombres de las secuencias


# 8.5 Acceder a las secuencias de mi objeto DNAStringSet


# 8.5.1 una secuencia


# 8.5.2 mas de una secuencia


# 8.5.3 subset con un rango (inicio y final de la secuencia)


# 8.5.4 subset con un inicio o un final


#######################################################
##   Ejercicio 9. Frecuencias absolutas y relativas  ##  
#######################################################
# 9.1 Frecuencia de bases por cada secuencia


# 9.2 Frecuencia de bases totales


#######################################################
##   Ejercicio 10. Lectura y escritura de fastas    ###   
#######################################################
# 10.1 explorar objeto


# 10.2 Distribucion de las longitudes de las secuencias


# 10.3 Escritura de fastas


#######################################################
###            Ejercicio 11. Busqueda de patrones     #
#######################################################
# 11.1  Encontar un patron por ejemplo de una enzima


# 11.2 Conteo de patrones. Contenido de GC


# 11.3 guardar la imagen


#######################################################
###      Ejercicio 12. Alineamientos de secuencias    #
#######################################################
# 12.1 pairwiseAlignment


# Crear 2 secuencia S1 y S2


# 12.2 Crear una matrix de sustitucion de nucleotidos


#######################################################
####         Ejercicio 13. Trabajando con rBLAST     ##
#######################################################
# 13.1 Cargar libreria rBLAST


# 13.2 Cargar las secuencias Query


# 13.3 Cargar la base de datos


# 13.4 Alineamiento local con BLAST de 1 secuencia con un filtro de 99% identidad


# 13.5 Desplegar ayuda de BLAT


# 13.6 Alineamiento con opciones de BLAST especificas


#######################################################
#####                  ShortRead                    ###
#####     Ejercicio 14. Lectura y manejo de fastq   ###
#######################################################
# 14.1 Leer archivos fastq


# 14.1 muestreo aleatorio


# 14.2 acceder a un numero determinado de secuencias


# 14.3 acceder a la informacion de las secuencias


# 14.4 acceder a la calidad de las secuencias


# 14.5 ver los valores numericos de la calidad


# 14.6 Escritura de fastq


#######################################################
####    Evaluacion de la Calidad de la secuenciacion  #
####            Ejercicio 15. Libreria Rqc            #
#######################################################
# 15.1 Cargar libreria de trabajo


# 15.2 Cargar secuencias con rqc


# 15.2 Informacion general de mis archivos


# 15.3 Distribucion de calidad media por lectura de archivos


# 15.4 Distribucion de calidad especifica del ciclo: boxplot


# 15.5 Si solo queremos observar un archivo


# 15.6 Podemos extraer la informacion de cada uno de los ciclos


# 15.7 Proporción de llamada base específica del ciclo


# 15.8 Solo de un archivo


# 15.9 Frecuencias de lecturas


# Este grafico muestra la proporcian de lecturas que aparecieron muchas veces.


# 15.10 Distribucion del tamaño de las lecturas


#######################################################
####          Filtrado y recorte de lecturas         ##
####           Ejercicio 16. Libreria QuasR          ##
#######################################################
# 16.1 Cargar libreria de trabajo


# 16.2 Lectura de los archivos


# 16.2.1 Generar vectores de los paths de los archivos crudos 


# 16.2.2 Generar vectores de los nombres de los archivos de salida 


# Procesamiento de los archivos fastq 


# Quitar lecturas que tienen mas de 1 N (nBases)


# Cortar 3 bases del final de las lecturas (truncateEndBases)


# Quitar el patron "ACCCGGGA" si ocurre al principio (Lpattern)


# eliminar lecturas de menos de 280 pares de bases (minLength)


# 16.3 Tambien podemos leer archivos fastq y hacer el proceso paso a paso


# 16.4 obtener puntajes de calidad por base en forma de una matriz


# 16.5 obtener el numero de bases por lectura que tienen un puntaje de calidad inferior a 20


# usamos esto


# 16.6 Numero de lecturas en las que todas las puntuaciones de Phred >= 20


# 16.7 Escribimos fastq filtrado


######## Listado de Variables


######## Informacion de la sesion


