##############################################################################
#########                          PASPE 2025                        #########
#########      Analisis de datos de Ciencias Genomicas usando R      #########   
######       E. Ernestina Godoy Lozano (elizabeth.godoy@insp.mx)     #########
######                       Bitacora de comandos                    #########
######    UNIDAD 2. Bioconductor para analisis de secuencias cortas  #########
######          Secuencias, Alineamientos y Operaciones basicas      #########
##############################################################################

# Texto sin acentos

# Posicionarse en su directorio de trabajo
setwd("~/PASPE_2025_Datos_genomicos_R/2.Bioconductor")
getwd()

# Cargar librerias de trabajo
library(ShortRead)

# visualizar las librerias que son dependencias de ShortRead
sessionInfo()

# Cargar funcion plotRanges()
source("plotRanges.R")

#########################################################
#####                       IRanges                  ####
###   Ejercicio 1. Generacion de objetos de IRanges   ###
#########################################################
# 1.1 Cargar libreria de trabajo
library(IRanges)

# 1.2 Generar objeto chr con funcion IRanges()
chr2 <- IRanges(start=3,end=54)
chr2

# 1.2 Tipo de objeto
class(chr2)

# 1.3 Inicio del rango
start(chr2)

# 1.4 Final del rango
end(chr2)

# 1.5 ancho del rango
width(chr2)

# 1.6 Podemos solo especificar el ancho del rango y el inicio, sin el termino del rango
chr3 <- IRanges(start=5, width=20)
chr3

# 1.8 Multiples rangos
chrs <-IRanges(start=c(2,10,6,14,15,18,23), width=c(12,5,6,6,7,2,3))
chrs

# 1.9 Longitud de mi objeto chrs
length(chrs)

# 1.10 Añadir nombres a los rangos usando "paste"
names(chrs) <- paste("Chr", 1:7, sep="_")
chrs

# 1.11 Generar grafico con plotRanges()
plotRanges(chrs)

# 1.12 guardar la imagen con png()
png ("figuras/ranges_chrs.png", width=300*8, height=300*6, res=300, units="px")
plotRanges(chrs)
dev.off()

#########################################################
###            Ejercicio 2. Subsets de rangos         ###
#########################################################
# 2.1 Valores subsecuentes. Extraer los chrs de la posicion 2 a la 4
chrs[2:4]

# 2.2 Valores salteados. Extraer los chrs 1, 6 y 3
chrs[c(1,6,3)]

#########################################################
###       Ejercicio 3. Manejo de objetos IRanges      ###
#########################################################
# 3.1  Eliminar redundancia
reduce(chrs)

# 3.2 Añadir o disminuir el ancho de los rangos con los operadores - y +
chrs + 2
chrs - 1

# 3.3 Desplazar los rangos por un factor 
shift(chrs, 10) 

# 3.4 Encontrar sobrelapamientos
findOverlaps(chrs)

# 3.5 Cobertura
coverage(chrs)

# 3.6 Separacion de los rangos
disjoin(chrs)

# 3.7 Generar plot de disjoin
plotRanges(disjoin(chrs))

# 3.8 Guardar la imagen
png ("figuras/disjoin.png", width=300*8, height=300*6, res=300, units="px")
plotRanges(disjoin(chrs))
dev.off()

# 3.9 Encontrar los gaps
gaps(chrs)

# 3.10 Generar plot de gaps
plotRanges(gaps(chrs))

# 3.11 Guardar la imagen con png
png ("figuras/gaps.png", width=300*8, height=300*6, res=300, units="px")
plotRanges(gaps(chrs))
dev.off()

#########################################################
#####               GenomicRanges                     ###
#   Ejercicio 4. Generacion de objetos de GenomicRanges #
#########################################################

# 4.1 Cargar librerua GenomicRanges
library(GenomicRanges)

# 4.2 Genrerar objeto gr con funcion GRanges()
gr <- GRanges(seqnames = "chr1", strand = c("+", "-", "+"), 
              ranges = IRanges(start = c(1,3,5), width = 3))

# 4.3 Tipo de objeto
class(gr)

# 4.4 Añadir metadatos
values(gr) <- DataFrame(score = c(0.1, 0.5, 0.3),
                        GC_content=c(50, 34, 45))

# 4.5 Imprimir objeto gr
gr

# 4.6 Usar plotRanges()
plotRanges(gr)

# 4.7 Acceder a los metadatos
gr$score

# 4.8 Realizar operaciones con los metadatos
gr$score2 <- gr$score*2
gr

#########################################################
###    Ejercicio 5. Manejo de objetos GenomicRanges   ###
#########################################################

# 5.1 Generar objeto gr2 con 3 chromosomas
gr2 <- GRanges(seqnames = c("chr1", "chr4", "chr5"), 
               strand = c("-", "-", "+"), 
               ranges = IRanges(start = c(3,1,7), width = 4), 
               score= c(0.2,0.3, 0.5))
# 5.2 Usar plotRanges()
plotRanges(gr2)

# 5.3 Extraer nombres de las secuencias con "seqnames"
seqnames(gr2)

# 5.4 Rangos de las secuencias con "ranges"
ranges(gr2)

# 5.5 Cadenas de las secuencias con "strand"
strand(gr2)

# 5.6 Otra manera de acceder a los metadatos con "$" (columnas extras) y "mcols"
mcols(gr2)
mcols(gr2)$score

# 5.7 Sobrelapamientos con "findOverlaps"
findOverlaps(gr, gr2)
subsetByOverlaps(gr, gr2)

# 5.8 Generar un objeto GenomicRanges de un data frame
# Data frame
df <- data.frame(chr = "chr1", 
                 start = 1:3, 
                 end = 4:6, 
                 score = 7:9)
# Usar funcion makeGRangesFromDataFrame()
makeGRangesFromDataFrame(df)

# Añadiendo la opcion keep.extra.columns
makeGRangesFromDataFrame(df, keep.extra.columns = TRUE)

#########################################################
#####                  Biostrings                   #####
#Ejercicio 6. Creacion y manejo de objetos en Biostrings#
#########################################################
# 6.1 Cargar libreria Biostrings
library(Biostrings)

# 6.2 Variables para generar secuencias al azar
DNA_ALPHABET
AA_ALPHABET

# 6.3 Generacion de secuencia con la variable DNA_ALPHABET
seq <- sample(DNA_ALPHABET[1:4], size = 24, replace = TRUE)
seq
class(seq)
# 6.4 Generacion de objeto DNAString
seq <- DNAString(paste(seq, collapse= ""))
seq
class(seq)

# 6.5 Frecuencia de las bases
# 6.5.1 Frecuencia absoluta
alphabetFrequency(seq, baseOnly=TRUE, as.prob=FALSE)
letterFrequency(seq, "A")
letterFrequency(seq, "GC")

# 6.5.2 Frecuencia relativa
alphabetFrequency(seq, baseOnly=TRUE, as.prob=TRUE)
letterFrequency(seq, "A", as.prob=TRUE)
letterFrequency(seq, "GC", as.prob=TRUE)

# 6.6 Longitud
length(seq)

# 6.7 Acceso a bases individuales. Obtener la base numero 4 de mi secuencia "seq"
seq[4]

# 6.8 Acceso a una parte de la secuencia; con un rango
seq[4:13]

#########################################################
#####                  Biostrings                   #####
####         Ejercicio 7. Transformaciones basicas    ###
#########################################################

# 7.1 Reverso 
rev(seq)

# 7.2 complemento
complement(seq)

# 7.3 Reverso complementario
reverseComplement(seq)

# 7.4 Traduccion
translate(seq)

# 7.5 juntar las funciones
translate(reverseComplement(seq))

#########################################################
#####        Ejercicio 8. Subsets de secuencias      ####
#########################################################

# 8.1 Cargar libreria ShortRead
library(ShortRead)

# 8.2 Crear un objeto de mas de una secuencia
set_seq <- NULL
for(i in 1:4){
	set_seq <- c(set_seq, 
	             paste(sample(DNA_ALPHABET[1:4], 30, replace= T), 
	                   collapse = ""))
}

set_seq
set_seq <- DNAStringSet(set_seq)
names(set_seq) <- c(paste("Seq", seq(1,4,1), sep="_"))
set_seq

# 8.3 Longitud de las secuencias en un objeto con mas de una secuencia
length(set_seq)
width(set_seq)
nchar(set_seq)

# 8.4 nombres de las secuencias
names(set_seq)

# 8.5 Acceder a las secuencias de mi objeto DNAStringSet
# 8.5.1 una secuencia
set_seq[1]

# 8.5.2 mas de una secuencia
set_seq[c(3,1,4)]

# 8.5.3 subset con un rango (inicio y final de la secuencia)
subseq(set_seq, start=3, end=10)

# 8.5.4 subset con un inicio o un final
subseq(set_seq, start=5)
subseq(set_seq, end=20)

#########################################################
##   Ejercicio 9. Frecuencias absolutas y relativas    ##
#########################################################
# 9.1 Frecuencia de bases por cada secuencia
alphabetFrequency(set_seq, baseOnly=TRUE, as.prob=TRUE)

# 9.2 Frecuencia de bases totales
alphabetFrequency(set_seq, baseOnly=TRUE, as.prob=TRUE, collapse=T)
letterFrequency(set_seq, "GC", as.prob=TRUE)

#########################################################
##   Ejercicio 10. Lectura y escritura de fastas       ##
#########################################################
secuencias <- readDNAStringSet("raw_data/alkB1.fa") 

# 10.1 explorar objeto
secuencias
length(secuencias)

# 10.2 Distribucion de las longitudes de las secuencias
hist(width(secuencias), breaks = 20, col="blue")

# 10.3 Escritura de fastas
secuencias2 <- secuencias[c(1,2,5)]
writeXStringSet(secuencias2, "raw_data/alkB1_3seq.fa", format="fasta")
dir("raw_data")

#########################################################
###            Ejercicio 11. Busqueda de patrones     ###
#########################################################
# 11.1  Encontar un patron por ejemplo de una enzima
EcoRI <- DNAString("GAATTC")
matches <- vmatchPattern(EcoRI, secuencias2)
matches

# 11.2 Conteo de patrones. Contenido de GC
letterFrequency(secuencias, "GC", as.prob=TRUE)

frecuenciasGC = vcountPattern("CG", secuencias) / width(secuencias)
frecuenciasAT = vcountPattern("AT", secuencias) / width(secuencias)

b <- seq(0, 0.15, length = 30)
hist(frecuenciasGC, col = "#7f78da", xlim = c(0, 0.25), breaks = b, main = "Frequencies of CG content")
hist(frecuenciasAT, col = "#da77a2", add = T, breaks = b)
legend("topright", c("GC content", "AT content"), fill = c("#7f78da", "#da77a2"))

# 11.3 guardar la imagen
png ("figuras/frqCG_AT.png", width=300*8, height=300*6, res=300, units="px")
hist(frecuenciasGC, col = "#7f78da", xlim = c(0, 0.25), breaks = b, main = "Frequencies of CG content")
hist(frecuenciasAT, col = "#da77a2", add = T, breaks = b)
legend("topright", c("GC content", "AT content"), fill = c("#7f78da", "#da77a2"))
dev.off()

#########################################################
###      Ejercicio 12. Alineamientos de secuencias    ###
#########################################################
# 12.1 pairwiseAlignment
# Crear 2 secuencia S1 y S2
s1 <- subseq(secuencias[1], start=3, width=40)
s2 <- subseq(secuencias[2], start=1, width=30)

# 12.2 Crear una matrix de sustitucion de nucleotidos
mat <- nucleotideSubstitutionMatrix(match = 1, mismatch = -3, baseOnly = TRUE)

aln_global <- pairwiseAlignment(s1, s2, substitutionMatrix = mat, gapOpening = 5, gapExtension = 2)
aln_global
aln_local <- pairwiseAlignment(s1, s2, type = "local", substitutionMatrix = mat, gapOpening = 5, gapExtension = 2)
aln_local
aln_overlap <- pairwiseAlignment(s1, s2, type = "overlap", substitutionMatrix = mat, gapOpening = 5, gapExtension = 2)
aln_overlap

#########################################################
####         Ejercicio 13. Trabajando con rBLAST     ####
#########################################################

# 13.1 Cargar libreria rBLAST
library(rBLAST)

# 13.2 Cargar las secuencias Query
seq <- readDNAStringSet("raw_data/secuencias16S.fa")
seq

# 13.3 Cargar la base de datos
bl <- blast(db="/mnt/datos/database/16SMicrobial/16SMicrobial")

# 13.4 Alineamiento local con BLAST de 1 secuencia con un filtro de 99% identidad
cl <- predict(bl, seq[1,], BLAST_args = "-perc_identity 99")
cl

# 13.5 Desplegar ayuda de BLAT
blast_help(type = "blastn")


# 13.6 Alineamiento con opciones de BLAST especificas
resultados <- predict(bl, seq,
                      BLAST_args = c("-perc_identity 99", "-evalue 0.0000001"),
                      custom_format = "qseqid sseqid pident bitscore evalue length stitle")
resultados

#########################################################
#####                  ShortRead                    #####
#####     Ejercicio 14. Lectura y manejo de fastq   #####
#########################################################

# 14.1 Leer archivos fastq
fastq<- readFastq ("raw_data/antibodies.fastq")
fastq

# 14.1 muestreo aleatorio
subset_fastq <- sample(fastq, 1000)
subset_fastq

# 14.2 acceder a un numero determinado de secuencias
subset_fastq <- fastq[1:500]
subset_fastq

subset_fastq <- fastq[c(1:20, 30:500, 3000)]

# 14.3 acceder a la informacion de las secuencias
sread(subset_fastq)

# 14.4 acceder a la calidad de las secuencias
quality(subset_fastq)

# 14.5 ver los valores numericos de la calidad
encoding(quality(subset_fastq))

# 14.6 Escritura de fastq
writeFastq (subset_fastq, "raw_data/subset_antibodies.fastq")

#########################################################
####    Evaluacion de la Calidad de la secuenciacion  ###
####            Ejercicio 15. Libreria Rqc            ###
#########################################################
# 15.1 Cargar libreria de trabajo
library(Rqc)
options(device.ask.default = FALSE)

# 15.2 Cargar secuencias con rqc
qcRes <- rqc(path = "paired_reads", pattern = ".fastq", openBrowser=FALSE, pair = c(1,1))

# 15.2 Informacion general de mis archivos
perFileInformation(qcRes)

# 15.3 Distribucion de calidad media por lectura de archivos
rqcReadQualityBoxPlot(qcRes)

# 15.4 Distribucion de calidad especifica del ciclo: boxplot
rqcCycleQualityBoxPlot(qcRes)

# 15.5 Si solo queremos observar un archivo
rqcCycleQualityBoxPlot(qcRes[1])

# 15.6 Podemos extraer la informacion de cada uno de los ciclos
lista_file1 <- rqcCycleQualityBoxPlot(qcRes[1])
str(lista_file1)
View(lista_file1$data)

# 15.7 Proporción de llamada base específica del ciclo
rqcCycleBaseCallsLinePlot(qcRes)

# 15.8 Solo de un archivo
rqcCycleBaseCallsLinePlot(qcRes[1])

# 15.9 Frecuencias de lecturas
# Este grafico muestra la proporcian de lecturas que aparecieron muchas veces.
rqcReadFrequencyPlot(qcRes)

# 15.10 Distribucion del tamaño de las lecturas
rqcReadWidthPlot(qcRes)

#########################################################
####          Filtrado y recorte de lecturas         ####
####           Ejercicio 16. Libreria QuasR          ####
#########################################################

# 16.1 Cargar libreria de trabajo
library(QuasR)

# 16.2 Lectura de los archivos
# 16.2.1 Generar vectores de los paths de los archivos crudos 
fastqFiles <- c("paired_reads/Cru1_S1_SED_R1.fastq", "paired_reads/Cru1_S1_SED_R2.fastq")

# 16.2.2 Generar vectores de los nombres de los archivos de salida 
outfiles <-c("processed_data/processed_Cru1_S1_SED_R1.fastq", "processed_data/processed_Cru1_S1_SED_R2.fastq")

# Procesamiento de los archivos fastq 
# Quitar lecturas que tienen mas de 1 N (nBases)
# Cortar 3 bases del final de las lecturas (truncateEndBases)
# Quitar el patron "ACCCGGGA" si ocurre al principio (Lpattern)
# eliminar lecturas de menos de 280 pares de bases (minLength)

preprocessReads(fastqFiles, outfiles, 
                nBases=1,
                truncateEndBases=3,
                Lpattern="ACCCGGGA",
                minLength=280)

# 16.3 Tambien podemos leer archivos fastq y hacer el proceso paso a paso
fastqFile <- system.file(package="ShortRead",
                         "extdata/E-MTAB-1147",
                         "ERR127302_1_subset.fastq.gz")
fq = readFastq(fastqFile)

# 16.4 obtener puntajes de calidad por base en forma de una matriz
qPerBase = as(quality(fq), "matrix")

# 16.5 obtener el numero de bases por lectura que tienen un puntaje de calidad inferior a 20
# usamos esto
qcount = rowSums( qPerBase <= 20) 

# 16.6 Numero de lecturas en las que todas las puntuaciones de Phred >= 20
fq[qcount == 0]

# 16.7 Escribimos fastq filtrado
writeFastq(fq[qcount == 0], "processed_data/ERR127302_1_subset_filterQ20.fastq.gz")


######## Listado de Variables
ls()

######## Informacion de la sesion
sessionInfo()
