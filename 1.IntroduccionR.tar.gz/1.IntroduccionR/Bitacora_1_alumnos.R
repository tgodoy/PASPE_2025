#######################################################################
#########                       PASPE 2025                     ########
#########   Analisis de datos de Ciencias Genomicas usando R   ########
######### E. Ernestina Godoy Lozano (elizabeth.godoy@insp.mx)  ########
#########                 Bitacora de comandos 1               ########
#########          UNIDAD 1. Introduccion a Bioconductor       ########
#########           Sesion 1 y 2. Comandos basicos             ########
#######################################################################
# Texto sin acentos

######################################################
###          ORGANIZACION DE ESPACIO DE TRABAJO     ##
######################################################
# 1. En donde estamos parados


# 2. Posicionarme en donde quiero generar el directorio de trabajo


# 3. Crear directorio "PASPE_2023_Datos_genomicos_R"


# 4. Entrar al directorio "PASPE_2023_Datos_genomicos_R"


######################################################
###     Ejercicio 1. Instalacion de librerias de    ##
###                      Bioconductor               ##
######################################################
#if (!requireNamespace("BiocManager", quietly = TRUE))


#install.packages("BiocManager")


# Instalacion de "GenomicRanges"


#BiocManager::install("GenomicRanges")


######################################################
### Ejercicio 2. Instalacion de librerias de CRAN    #
######################################################
#install.packages("vegan", dependencies=T)


######################################################
###              Ejercicio 3. Variables             ##
######################################################
# 3.1 variable_caracter


# 3.2 variable_numerica


# 3.3 variable_logica


# 3.4 Determinar la clase de mis variables


######################################################
####      Ejercicio 4. Operaciones basicas         ###
######################################################
# 4.1 Generacion de objetos con seq() y rep()


# 4.2 Exploracion de las dimenciones de mis objetos


# 4.3 Operaciones basicas


# 4.4 Funciones especiales sum(), mean() y sd()


# 4.5 Adicionar mas de un caracter o un numero a mi variable


# 4.6 Pegado de textos con paste()


######################################################
###                 Ejercicio 5. Data input         ##
######################################################
# 5.1 Leer tabla "abiotic_variables.txt"


# 5.2 Observar la tabla


# 5.3 Leer tabla "abiotic_variables.txt" y que los nombres de las filas 


# sean el identificador de la muestra


# 5.4 Explorar la tabla variables


######################################################
### Ejercicio 6. Acceder a los elementos de la tabla #
######################################################
# 6.1 Dimensiones de mi data.frame


# 6.2 Columnas


# 6.2.1 una sola columna


# 6.2.2. Dos o mas columnas seguidas


# 6.2.3 Dos o mas columnas en desorden 


# 6.3 Filas


# 6.3.1 una sola fila


# 6.3.2 Dos o mas filas seguidas


# 6.3.3 Dos o mas columnas en desorden 


# 6.4 Con un valor especifico con los nombres de las columnas o filas


# 6.4.1 una sola variable columnas


# 6.4.2 dos o mas variables


# 6.4.3 una sola variable filas


# 6.4.4 dos o mas variables


# 6.4.5 con un rango determinado de valores


# 6.4.6 Obtener el valor


# 6.4.7 Obtener el nombre de la estacion


######################################################
### Ejercicio 7. Adicion de columnas y filas a tablas 
######################################################
# 7.1 Crear un objetos con una variable extra usemos rnorm()


# 7.2 Sumamos un dos a toda la fila, solo las columnas numericas


# 7.3 Completar la columna de Clase que nos falta


# 7.4 Cambiar nombre de la fila


# 7.5 Verificar dimensiones de tabla original


# 7.6 unir las columnas con cbind


# 7.7 unir las filas con rbind


######################################################
###        Ejercicio 8. Generacion de matrices      ##
######################################################
# 8.1 Chequemos nuevamente las dimenciones de nuestro objeto variables


# 8.2 generar una matrix vacia


# 8.3 generar una matrix con datos


# 8.4 Cambiar nombres de columnas y filas


######################################################
###           Ejercicio 9. Escritura de datos       ##
######################################################
# 9.1 Escribir texto delimitado por tabuladores


# 9.2 Escribir texto delimitado por comas


# 9.3 Listar archivos de un directorio


######################################################
###          Ejercicio 10. Libreria dplyr()         ##
######################################################
# 10.1 Cargar libreria


# 10.2 Extraer solo unas cuentas columnas de variables


# 10.3 Seleccionar columnas especificas con select()


# 10.4 Filtrar estaciones con Phenanthrene > 7 con filter()


# 10.5 Crear una nueva columna que calcule la suma de dos compuestos


# 10.6 Ordenar por la cantidad de Phenanthrene, de mayor a menor


# 10.7 Usemos dos pipes


# 10.8 Tradicional


# 10.9 Con pipe


# Ejercicio para clase:


# 1. Seleccionar columnas de hidrocarburos.


# 2. Filtrar muestras con "Deep" > 1000.


# 3. Calcular la media de materia orgánica por grupo ("Clase").


# 4. Crear una nueva columna con un índice HC_aromáticos/HC_alifáticos.


# 5. Ordenar por ese índice de mayor a menor


######################################################
###      Ejercicio 11. Estructuras de control       ##
###                    Ciclos FOR                   ##
######################################################
# 11.1 Chequemos los nombres de nuestras columnas


# 11.2 Creemos objetos HC_alifaticos y HC_aromaticos


# 11.3 Creemos una nueva tabla en donde sumaremos los HC


# 11.3.1 Creemos la tabla vacia


# 11.3.2 Añadamos nombres de columnas y filas


# 11.3.3 Necesitamos las posiciones de cada HC para sumarlos


# 11.3.4 Llenemos nuestra tabla con el ciclo for ()


######################################################
###      Ejercicio 12. Estructuras de control       ##
###                    if and else                  ##
######################################################
# 12.1 Usemos if and else con numeros


######################################################
###      Ejercicio 13. Estructuras de control       ##
###                    ifelse                       ##
######################################################
# 13.1 Generemos una cadena de 10 numeros 


# 13.2 usemos ifelse para sacar pares y nones


# 13.3 ifelse para decodificar variables


######################################################
###      Ejercicio 13. Estructuras de control       ##
###                     while                       ##
######################################################
# 13.1 Necesitamos un contador en 0


# 13.2 Si el contador llega hasta 10 que deje de contar


######################################################
###     Ejercicio 14. Familia apply --> sapply      ##
######################################################
# 14.1 Verifiquemos nuestro objeto nueva_tabla


# 14.2 Convertir nueva_tabla a data.frame


# 14.3 Agreguemos una nueva columna con la clase de cada muestra 


# 14.4 Verifiquemos que esta la nueva columna


# 14.5 Cambiemos de string a factor


######################################################
###       Ejercicio 15. Listado de variables        ##
###             e Informacion de la sesion          ##
######################################################
