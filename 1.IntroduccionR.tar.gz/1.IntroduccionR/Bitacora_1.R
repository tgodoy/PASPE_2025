########################################################################
#########                       PASPE 2025                     #########
#########   Analisis de datos de Ciencias Genomicas usando R   #########   
######### E. Ernestina Godoy Lozano (elizabeth.godoy@insp.mx)  #########
#########                 Bitacora de comandos 1               #########
#########          UNIDAD 1. Introduccion a Bioconductor       #########
#########           Sesion 1 y 2. Comandos basicos             #########
########################################################################

# Texto sin acentos
#######################################################
###          ORGANIZACION DE ESPACIO DE TRABAJO     ###
#######################################################
# 1. En donde estamos parados
getwd()

# 2. Posicionarme en donde quiero generar el directorio de trabajo
setwd("Cambiar a la ruta del directorio de trabajo")

# 3. Crear directorio "PASPE_2023_Datos_genomicos_R"
dir.create("PASPE_2025_Datos_genomicos_R")

# 4. Entrar al directorio "PASPE_2023_Datos_genomicos_R"
setwd("PASPE_2025_Datos_genomicos_R")

#######################################################
###     Ejercicio 1. Instalacion de librerias de    ###
###                      Bioconductor               ###
#######################################################
#if (!requireNamespace("BiocManager", quietly = TRUE))
#install.packages("BiocManager")

# Instalacion de "GenomicRanges"
#BiocManager::install("GenomicRanges")

#######################################################
### Ejercicio 2. Instalacion de librerias de CRAN    ##
#######################################################
#install.packages("vegan", dependencies=T)

#######################################################
###              Ejercicio 3. Variables             ###
#######################################################
# 3.1 variable_caracter
variable_caracter <- "Caracteres"
variable_caracter

# 3.2 variable_numerica
variable_numerica <- 1029
variable_numerica

# 3.3 variable_logica
variable_logica <- TRUE
variable_logica

# 3.4 Determinar la clase de mis variables
class(variable_caracter)
str(variable_numerica)
typeof(variable_logica)

#######################################################
####      Ejercicio 4. Operaciones basicas         ####
#######################################################
# 4.1 Generacion de objetos con seq() y rep()
x <- seq (1,10,1)
y <- rep (2,10)

# 4.2 Exploracion de las dimenciones de mis objetos
length(x)
length(y)

# 4.3 Operaciones basicas
suma <- x + y
suma
multiplicacion <- x * y
multiplicacion
resta <- x - y
resta
division <- x/y 
division

# 4.4 Funciones especiales sum(), mean() y sd()
x
sum(x)
mean(x)
sd(x)

# 4.5 Adicionar mas de un caracter o un numero a mi variable
numeros <- c(10,22,30)
numeros
letras <- c("A", "B", "C")
letras
ambos <- c("A", 15, "B", 30)
ambos
ambos <- c(15, "A", 30, "B")
ambos

# 4.6 Pegado de textos con paste()
texto <- c (rep ("gen",5), rep ("protein",5))
paste (texto, x, sep="-")

#######################################################
###                 Ejercicio 5. Data input         ###
#######################################################
# 5.1 Leer tabla "abiotic_variables.txt"
variables <- read.delim("tablas/abiotic_variables.txt", header=T)

# 5.2 Observar la tabla
View(variables)

# 5.3 Leer tabla "abiotic_variables.txt" y que los nombres de las filas 
# sean el identificador de la muestra
variables <- read.delim("tablas/abiotic_variables.txt", header=T, row.names=1)

# 5.4 Explorar la tabla variables

head(variables)
dim(variables)
summary(variables)

#######################################################
### Ejercicio 6. Acceder a los elementos de la tabla ##
#######################################################

# 6.1 Dimensiones de mi data.frame
dim(variables)

# 6.2 Columnas
# 6.2.1 una sola columna
variables[,3]
variables$Total_Co

# 6.2.2. Dos o mas columnas seguidas
variables[,1:3]

# 6.2.3 Dos o mas columnas en desorden 
variables[,c(2,5,6,1)]

# 6.3 Filas
# 6.3.1 una sola fila
variables[1,]

# 6.3.2 Dos o mas filas seguidas
variables[3:6,]

# 6.3.3 Dos o mas columnas en desorden 
variables[c(12,6,1),]

# 6.4 Con un valor especifico con los nombres de las columnas o filas
# 6.4.1 una sola variable columnas
which(colnames(variables)=="Heneicosane")
variables[,which(colnames(variables)=="Heneicosane")]

# 6.4.2 dos o mas variables
variables_interes <- c("Heneicosane", "Total_Ba", "Hexacosane")
which(colnames(variables) %in% variables_interes)
variables[,which(colnames(variables) %in% variables_interes)]

# 6.4.3 una sola variable filas
which(rownames(variables)=="Someras_S2")
variables[which(rownames(variables)=="Someras_S2"),]

# 6.4.4 dos o mas variables
variables_interes <- c("Costa_S1", "Costa_S2", "Profundas_S4")
which(rownames(variables) %in% variables_interes)
variables[which(rownames(variables) %in% variables_interes),]

# 6.4.5 con un rango determinado de valores
summary(variables$Phenanthrene)

# 6.4.6 Obtener el valor
variables$Phenanthrene[which(variables$Phenanthrene>7)]

# 6.4.7 Obtener el nombre de la estacion
rownames(variables)[which(variables$Phenanthrene>7)]
variables[which(variables$Phenanthrene>7),17:18]

#######################################################
### Ejercicio 7. Adicion de columnas y filas a tablas #
#######################################################
# 7.1 Crear un objetos con una variable extra usemos rnorm()

extra_columna <- data.frame(Col_extra = c(rnorm(5, 31.8762, 0.233), 
                                          rnorm(5, 41.6213, 0.278), 
                                          rnorm(5, 11.4534, 0.3123)))

# 7.2 Sumamos un dos a toda la fila, solo las columnas numericas
extra_fila <- data.frame(variables[2,1:35] + 2)

# 7.3 Completar la columna de Clase que nos falta
extra_fila$Clase <- "Costa"

# 7.4 Cambiar nombre de la fila
rownames(extra_fila) <- "Fila_extra"

# 7.5 Verificar dimensiones de tabla original
dim(variables)

# 7.6 unir las columnas con cbind
tabla_con_columna_extra <- cbind(variables, extra_columna)
dim(tabla_con_columna_extra)

# 7.7 unir las filas con rbind
tabla_con_fila_extra <- rbind(extra_fila,variables)
dim(tabla_con_fila_extra)

#######################################################
###        Ejercicio 8. Generacion de matrices      ###
#######################################################

# 8.1 Chequemos nuevamente las dimenciones de nuestro objeto variables
dim(variables)

# 8.2 generar una matrix vacia
nueva_tabla <- matrix(nrow=15, ncol=36)

# 8.3 generar una matrix con datos
nueva_tabla <- matrix(data=0, nrow=15, ncol=36)

# 8.4 Cambiar nombres de columnas y filas
colnames(nueva_tabla) <- colnames(variables)
rownames(nueva_tabla) <- rownames(variables)

#######################################################
###           Ejercicio 9. Escritura de datos       ###
#######################################################
# 9.1 Escribir texto delimitado por tabuladores
write.table(nueva_tabla, "tablas/tabla_vacia.txt", 
            sep="\t", quote=FALSE, row.names= TRUE, col.names= TRUE)

# 9.2 Escribir texto delimitado por comas
write.csv(nueva_tabla, "tablas/tabla_vacia.csv", quote=FALSE, row.names=TRUE)

# 9.3 Listar archivos de un directorio
dir ("tablas/")

#######################################################
###          Ejercicio 10. Libreria dplyr()         ###
#######################################################
# 10.1 Cargar libreria
library(dplyr)

# 10.2 Extraer solo unas cuentas columnas de variables
data <- variables[,c(1,2,14,16,18,36)]

# 10.3 Seleccionar columnas especificas con select()
data %>%
  select(Naphthalene, Fluorene, Undecane)

# 10.4 Filtrar estaciones con Phenanthrene > 7 con filter()
data %>% 
  filter(Phenanthrene > 7)

# 10.5 Crear una nueva columna que calcule la suma de dos compuestos
data %>%
  mutate(Suma_HA = Undecane + Dodecane)

# 10.6 Ordenar por la cantidad de Phenanthrene, de mayor a menor
data %>%
  arrange(desc(Phenanthrene))

# 10.7 Usemos dos pipes
data %>% 
  group_by(Clase) %>% 
  summarise(Promedio_NF = mean(Naphthalene, na.rm = TRUE))

# 10.8 Tradicional
mean(data$Undecane)

# 10.9 Con pipe
data %>% 
  pull(Undecane) %>% 
  mean()

# Ejercicio para clase:
# 1. Seleccionar columnas de hidrocarburos.
# 2. Filtrar muestras con "Deep" > 1000.
# 3. Calcular la media de materia orgánica por grupo ("Clase").
# 4. Crear una nueva columna con un índice HC_aromáticos/HC_alifáticos.
# 5. Ordenar por ese índice de mayor a menor

#######################################################
###      Ejercicio 11. Estructuras de control       ###
###                    Ciclos FOR                   ###
#######################################################
# 11.1 Chequemos los nombres de nuestras columnas
as.data.frame(colnames(variables))

# 11.2 Creemos objetos HC_alifaticos y HC_aromaticos
HC_alifaticos <- colnames(variables)[1:13]
HC_aromaticos <- colnames(variables)[14:21]

# 11.3 Creemos una nueva tabla en donde sumaremos los HC
# 11.3.1 Creemos la tabla vacia
nueva_tabla <- matrix(ncol=4, nrow=dim(variables)[1])
head(nueva_tabla)

# 11.3.2 Añadamos nombres de columnas y filas
colnames(nueva_tabla) <- c("HC_alifaticos_totales", 
                           "HC_aromaticos_totales", 
                           "Organic_Matter", "Deep")
rownames(nueva_tabla) <- rownames(variables)

# 11.3.3 Necesitamos las posiciones de cada HC para sumarlos
num_alif <- which(colnames(variables)%in%HC_alifaticos)
num_arom <- which(colnames(variables)%in% HC_aromaticos)

# 11.3.4 Llenemos nuestra tabla con el ciclo for ()
for (i in 1:dim(nueva_tabla)[1]){
	nueva_tabla[i,1] <- rowSums(variables[i,num_alif])
	nueva_tabla[i,2] <- rowSums(variables[i,num_arom])
	nueva_tabla[i,3] <- variables[i, which(colnames(variables)=="Organic_Matter")]
	nueva_tabla[i,4] <- variables[i, which(colnames(variables)=="Deep")]
}

head(nueva_tabla)

#######################################################
###      Ejercicio 12. Estructuras de control       ###
###                    if and else                  ###
#######################################################
# 12.1 Usemos if and else con numeros
if (10>50) {
	print("Verdadero")
} else {
	print ("Falso")
}


#######################################################
###      Ejercicio 13. Estructuras de control       ###
###                    ifelse                       ###
#######################################################
# 13.1 Generemos una cadena de 10 numeros 
num <- 1:10

# 13.2 usemos ifelse para sacar pares y nones
ifelse(num %% 2 == 0, "Par", "Non")

# 13.3 ifelse para decodificar variables
num <- c(1,0,0,0,0,0,1,1,0,1,1,0)
num <- ifelse(num == 0, "Hombre", "Mujer")
num
#######################################################
###      Ejercicio 13. Estructuras de control       ###
###                     while                       ###
#######################################################
# 13.1 Necesitamos un contador en 0
count <- 0

# 13.2 Si el contador llega hasta 10 que deje de contar
while (count < 10){
	print(count)
	count <- count +1
}
#######################################################
###     Ejercicio 14. Familia apply --> sapply      ###
#######################################################
# 14.1 Verifiquemos nuestro objeto nueva_tabla
class(nueva_tabla)

# 14.2 Convertir nueva_tabla a data.frame
nueva_tabla <- as.data.frame(nueva_tabla)

# 14.3 Agreguemos una nueva columna con la clase de cada muestra 
nueva_tabla$Clase <-sapply(as.character(rownames(nueva_tabla)), 
                           function(x){strsplit(x, "_")[[1]][1]}) 

# 14.4 Verifiquemos que esta la nueva columna
head(nueva_tabla)
View(nueva_tabla)
summary(nueva_tabla)

# 14.5 Cambiemos de string a factor
nueva_tabla$Clase <- as.factor(nueva_tabla$Clase)
summary(nueva_tabla)

#######################################################
###       Ejercicio 15. Listado de variables        ###
###             e Informacion de la sesion          ###
#######################################################
ls()
sessionInfo()