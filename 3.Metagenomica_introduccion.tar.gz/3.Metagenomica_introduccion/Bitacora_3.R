##############################################################################
#########                          PASPE 2025                        #########
#########      Analisis de datos de Ciencias Genomicas usando R      #########   
#########    E. Ernestina Godoy Lozano (elizabeth.godoy@insp.mx)     #########
#########                    Bitacora de comandos                    #########
#########                     UNIDAD 3. METAGENOMICA                 #########
#########             Exploracion de matrices de abundancia          #########
##############################################################################

# Texto sin acentos

# Cargar librerias de trabajo

library(gplots)
library(ggplot2)
library(vegan)
library(reshape2)
library(metagenomeSeq)
library(tidyverse)

# Cargar funciones extras
source("funciones/abund_relativa.R")
source("funciones/taxonomic_levels.R")

# Posicionarme en mi espacio de trabajo
getwd()
setwd("~/PASPE_2023_Datos_genomicos_R/3.Metagenomica_introduccion")

# Cargar datos
tabla <- read.delim("tablas/integrated_matrix.txt", header=TRUE, row.names=1)
head(tabla)
dim(tabla)

#######################################
####    Matrices de abundancia     ####
#######################################

# Ejercicio 1. Niveles taxonomicos

## 1.1 Añadir los nombres de los taxa a un objeto
asignacion_taxonomica <- data.frame(completo=rownames(tabla))
View(asignacion_taxonomica)

## 1.2 Asignar los taxa a su nivel taxonomico correspondiente
asignacion_taxonomica <- asignacion_taxonomica %>%
  separate(completo, into = c("Domain", "Phylum", "Class", 
                              "Order", "Family", "Genus", 
                              "Species", "Subspecies"),
           sep = ";", fill = "right", remove = FALSE)

View(asignacion_taxonomica)
head(asignacion_taxonomica)
View(asignacion_taxonomica)

## 1.3 Comprimir matriz a los distintos niveles taxonomicos
asig_unicas <- unique(asignacion_taxonomica$Phylum)
taxa_level <- matrix(data=0, nrow=length(asig_unicas) , ncol=dim(tabla)[2])

colnames(taxa_level) <- colnames(tabla)
rownames(taxa_level) <- asig_unicas
dim(taxa_level)

for (i in 1:dim(taxa_level)[1]){
	bicho <- rownames(taxa_level)[i]
	nums <- which(asignacion_taxonomica$Phylum== bicho)
	for (j in 1:dim(taxa_level)[2]){
		taxa_level[i,j] <- sum(tabla[nums,j])
	}
}

head(taxa_level)
View(taxa_level)

## 1.4 Generaremos un ciclo for para obtener todos los niveles taxonomicos desde una sola instruccion
taxonomics_levels <- c("Domain", "Phylum", "Class", "Order", "Family", "Genus", "Species")
for (k in 1:length(taxonomics_levels)){
	nivel <- taxonomics_levels[k]
	asig_unicas <- unique(asignacion_taxonomica[,which(colnames(asignacion_taxonomica)== taxonomics_levels[k])])
	taxa_level <- matrix(data=0, nrow=length(asig_unicas) , ncol=dim(tabla)[2])
	colnames(taxa_level) <- colnames(tabla)
	rownames(taxa_level) <- asig_unicas
	for (i in 1:dim(taxa_level)[1]){
		bicho <- rownames(taxa_level)[i]
		nums <- which(asignacion_taxonomica[,which(colnames(asignacion_taxonomica)== taxonomics_levels[k])]== bicho)
		for (j in 1:dim(taxa_level)[2]){
			taxa_level[i,j] <- sum(tabla[nums,j])
		}
	}
	num_no_asignaciones <- which(rowSums(taxa_level)==0)
	if (length(num_no_asignaciones)>0){
		taxa_level <- taxa_level[-num_no_asignaciones,]
	}
	print(paste("El nivel taxonomico ", nivel, " contiene ", dim(taxa_level)[1], " asignaciones", sep=""))
	exportMat(taxa_level, file =paste("tablas/taxa_levels/",nivel, ".txt", sep=""))
}

## 1.5 Usar la funcion taxonomic_levels()
taxonomic_levels("tablas/integrated_matrix.txt", "tablas/taxa_levels/")

dir("tablas/taxa_levels")

# Ejercicio 2. Matrices de abundancia relativa

View(tabla)

## 2.1 Convertir una matriz de abundancia absoluta a relativa
totales <- colSums(tabla)
totales
tabla_rel <- matrix(nrow=dim(tabla)[1], ncol=dim(tabla)[2])
colnames(tabla_rel) <- colnames(tabla)
rownames(tabla_rel) <- rownames(tabla)

View(tabla_rel)

## 2.2 Llenar la matriz con la abundancia relativa usando la funcion sweep
##    abundancia/total_reads * 100
tabla_rel <- sweep(tabla, 2, totales, FUN = "/") * 100

View(tabla_rel)
colSums(tabla_rel)

exportMat(tabla_rel, file ="tablas/percent_integrated_matrix.txt")

## 2.3 Correr la funcion abund_relativa() para los niveles de Genero y Clase
abund_relativa("tablas/taxa_levels/Genus.txt", "tablas/percent_Genus.txt")
abund_relativa("tablas/taxa_levels/Class.txt", "tablas/percent_Class.txt")

dir("tablas")

# Ejercicio 3. Generacion de barras apiladas
## 3.1 Cargar matriz a nivel de clase en abundancias relativas
tabla <- read.delim("tablas/percent_Class.txt", header=T, row.names=1)
dim(tabla)

## 3.1 Contraer la informacion de la matrix en dos columnas (Fusionar la matriz)
melt_subtable <- melt(as.matrix(tabla))
head(melt_subtable)

## 3.3 Cambiar los nombres de las columnas 
colnames(melt_subtable) <- c("Taxa", "Sample", "Freq")

## 3.4 Ordene los nombres de los taxa de acuerdo a un orden alfabetico
melt_subtable$Taxa <- factor(melt_subtable$Taxa, levels=sort(rownames(tabla)))

## 3.5 Generar un vector de colores al azar
color = grDevices::colors()[grep('gr(a|e)y', grDevices::colors(), invert = T)]
my_color=sample(color, dim(tabla)[1], replace=FALSE)

## 3.6 Generar grafica de barras apiladas
ggplot(melt_subtable, aes(x=Sample, y=Freq, fill=Taxa)) + 
  geom_bar(stat="identity") +  
	scale_fill_manual(values=my_color, limits=rownames(tabla)) + 
	theme(axis.text.x = element_text(angle=30, hjust=1, vjust=1, size=8), 
	      panel.background= element_rect(fill = NA, colour = "black"), 
	      panel.grid.major = element_line(colour = "grey90"), 
	      legend.key = element_rect(fill = "white"), 
	      legend.text=element_text(size=8), 
	      legend.position="bottom") + 
	labs(x = "", y = "Relative abundance (%)", fill="") + 
  scale_y_continuous(breaks=c(0, 20, 40, 60, 80, 100))
ggsave("figuras/sock_plots_Class.png", device = "png", dpi = 300, 
       units = "px", bg = "white")


# Ejercicio 4. Cortes de abundancia en la matriz
View(tabla)
dim(tabla)

## 4.1 Cargar matriz a nivel de clase en abundancias relativas
#tabla <- read.delim("tablas/percent_Class.txt", header=T, row.names=1)
View(tabla)
dim(tabla)

## Determinar un corte de abundancia, aqui marcamos un corte del 1% ##
## 4.2 Establecer un corte al 1%
cutoff <- 1

## 4.3 Calcular la media por fila y filtrar las que son > 1%
tabla_filtrada <- tabla %>%
  as.data.frame() %>%
  rownames_to_column("Taxa") %>%
  mutate(Media = rowMeans(select(., -Taxa))) %>%
  filter(Media > cutoff) %>%
  arrange(desc(Media)) %>% # ordenar de mayor a menor la abundancia
  select(-Media)
View(tabla_filtrada)

## 4.4 Restaurar los nombres de fila y columna
new <- tabla_filtrada %>%
  column_to_rownames("Taxa")

## 4.5 Calcular totales y fila de "Abundance < 1%"
resto <- 100 - colSums(new)
fila_resto <- as.data.frame(t(resto))
rownames(fila_resto) <- paste("Abundance <", cutoff, "%")

## 4.6 Combinar las tablas
new <- bind_rows(new, fila_resto)

## 4.7 Escribir nueva matriz de abundancia
exportMat(as.matrix(new), file ="tablas/percent_Class_more_1_perc.txt")

## 4.8 Contraer la informacion de la matrix en dos columnas (Fusionar la matriz)
melt_subtable <- melt(as.matrix(new))

## 4.9 Cambiamos los nombres para no perdernos
colnames(melt_subtable)
colnames(melt_subtable) <- c("Taxa", "Sample","Freq")
head(melt_subtable)

## 4.10 Verificar que la columna taxa este de acuerdo al orden establecido
class(melt_subtable$Taxa)
levels(melt_subtable$Taxa)

## 4.11 Generar un vector de colores al azar
set.seed(54464)  # para reproducibilidad

## 4.12 Generar un vector de colores al azar con un color gris para los taxa menos abundantes
### Opcion 1:
my_color1 <- c(sample(color, dim(new)[1]-1, replace=FALSE), "gray")

### Opcion 2:
n_taxa <- nrow(new)
my_color2 <- c(colorRampPalette(brewer.pal(8, "Set1"))(n_taxa - 1), "gray")

# 10. Generar mi grafica de barras apiladas con el corte de abundancia
ggplot(melt_subtable, aes(x= Sample, y=Freq, fill=Taxa)) + geom_bar(stat="identity") +  
  scale_fill_manual(values=my_color1, limits=rownames(new)) + 
  theme(axis.text.x = element_text(angle=30, hjust=1, vjust=1, size=6), 
        panel.background= element_rect(fill = NA, colour = "black"), 
        panel.grid.major = element_line(colour = "grey90"), 
        legend.key = element_rect(fill = "white"), 
        legend.text=element_text(size=6), 
        legend.position="bottom") + 
  labs(x = "", y = "Relative abundance (%)", fill="") + 
  scale_y_continuous(breaks=c(0, 20, 40, 60, 80, 100))

## 4.13 Guardar imagen con la funcion ggsave()
ggsave("figuras/sock_plots_Class_more_1_perc.png", 
       device = "png", dpi = 300, units = "px", bg = "white")

##### Listado de objetos
ls()

#### Informacion de la sesion
sessionInfo()

