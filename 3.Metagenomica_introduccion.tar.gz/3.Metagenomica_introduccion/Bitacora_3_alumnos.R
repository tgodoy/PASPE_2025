##############################################################################
#########                          PASPE 2025                        #########
#########      Analisis de datos de Ciencias Genomicas usando R      #########   
#########    E. Ernestina Godoy Lozano (elizabeth.godoy@insp.mx)     #########
#########                    Bitacora de comandos                    #########
#########                     UNIDAD 3. METAGENOMICA                 #########
#########             Exploracion de matrices de abundancia          #########
##############################################################################
# Texto sin acentos
# Cargar librerias de trabajo

# Cargar funciones extras

# Posicionarme en mi espacio de trabajo

# Cargar datos


#######################################
####    Matrices de abundancia     ####
#######################################
# Ejercicio 1. Niveles taxonomicos
## 1.1 Añadir los nombres de los taxa a un objeto


## 1.2 Asignar los taxa a su nivel taxonomico correspondiente


## 1.3 Comprimir matriz a los distintos niveles taxonomicos


## 1.4 Generaremos un ciclo for para obtener todos los niveles taxonomicos desde una sola instruccion

## 1.5 Usar la funcion taxonomic_levels()

# Ejercicio 2. Matrices de abundancia relativa
## 2.1 Convertir una matriz de abundancia absoluta a relativa


## 2.2 Llenar la matriz con la abundancia relativa usando la funcion sweep


## 2.3 Correr la funcion abund_relativa() para los niveles de Genero y Clase

# Ejercicio 3. Generacion de barras apiladas
## 3.1 Cargar matriz a nivel de clase en abundancias relativas


## 3.2 Contraer la informacion de la matrix en dos columnas (Fusionar la matriz)


## 3.3 Cambiar los nombres de las columnas 


## 3.4 Ordene los nombres de los taxa de acuerdo a un orden alfabetico


## 3.5 Generar un vector de colores al azar

## 3.6 Generar grafica de barras apiladas


# Ejercicio 4. Cortes de abundancia en la matriz
## 4.1 Cargar matriz a nivel de clase en abundancias relativas


## 4.2 Establecer un corte al 1%


## 4.3 Calcular la media por fila y filtrar las que son > 1%


## 4.4 Restaurar los nombres de fila y columna


## 4.5 Calcular totales y fila de "Abundance < 1%"


## 4.6 Combinar las tablas


## 4.7 Escribir nueva matriz de abundancia


## 4.8 Contraer la informacion de la matrix en dos columnas (Fusionar la matriz)


## 4.9 Cambiamos los nombres para no perdernos


## 4.10 Verificar que la columna taxa este de acuerdo al orden establecido


## 4.11 Generar un vector de colores al azar


## 4.12 Generar un vector de colores al azar con un color gris para los taxa menos abundantes


## 4.13 Generar mi grafica de barras apiladas con el corte de abundancia


## 4.14 Guardar imagen con la funcion ggsave()


##### Listado de objetos

#### Informacion de la sesion

