#!/usr/bin/env Rscript
#  abund_relativa.R
#  Copyright 2024- E. Ernestina Godoy Lozano (elizabeth.godoy@insp.mx)
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#  Texto sin acentos
#  Funcion para generar una matrix de abundancia relativa 
#  a partir de una matrix de abundancia absoluta

abund_relativa <- function(input, output){
  tabla <- read.delim(input, header=TRUE, row.names=1)
  totales <- colSums(tabla)
  tabla_rel <- matrix(nrow=dim(tabla)[1], ncol=dim(tabla)[2])
  colnames(tabla_rel) <- colnames(tabla)
  rownames(tabla_rel) <- rownames(tabla)
  
  for (i in 1:dim(tabla)[1]){
    for (j in 1:dim(tabla)[2]){
      tabla_rel[i,j] <- (tabla[i,j]/totales[j])*100
    }
  }
  exportMat(tabla_rel, file = output)
}