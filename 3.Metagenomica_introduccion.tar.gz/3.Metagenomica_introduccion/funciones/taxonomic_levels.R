#!/usr/bin/env Rscript
#  taxonomic_levels.R
#  Copyright 2025- E. Ernestina Godoy Lozano (elizabeth.godoy@insp.mx)
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#  Texto sin acentos


# Generaremos un ciclo for para obtener todos los niveles taxonomicos desde una sola instruccion

taxonomic_levels <- function(tabla_final, outpath){
  tabla <- as.matrix((read.delim(tabla_final, header=TRUE, row.names = 1)))
  asignacion_taxonomica <- rownames(tabla) %>%
    as.data.frame() %>%
    setNames("completo") %>%
    separate(completo, into = c("Domain", "Phylum", "Class", "Order", "Family", "Genus", "Species", "Subspecies"),
             sep = ";", fill = "right", remove = FALSE)

  taxonomics_levels <- c("Domain", "Phylum", "Class", "Order", "Family", "Genus", "Species")
  for (k in 1:length(taxonomics_levels)){
    nivel <- taxonomics_levels[k]
    asig_unicas <- unique(asignacion_taxonomica[,which(colnames(asignacion_taxonomica)== taxonomics_levels[k])])
    taxa_level <- matrix(data=0, nrow=length(asig_unicas) , ncol=dim(tabla)[2])
    colnames(taxa_level) <- colnames(tabla)
    rownames(taxa_level) <- asig_unicas
    for (i in 1:dim(taxa_level)[1]){
      bicho <- rownames(taxa_level)[i]
      nums <- which(asignacion_taxonomica[,which(colnames(asignacion_taxonomica)== taxonomics_levels[k])]== bicho)
      for (j in 1:dim(taxa_level)[2]){
        taxa_level[i,j] <- sum(tabla[nums,j])
      }
    }
    num_no_asignaciones <- which(rowSums(taxa_level)==0)
    if (length(num_no_asignaciones)>0){
      taxa_level <- taxa_level[-num_no_asignaciones,]
    }
    print(paste("El nivel taxonomico ", nivel, " contiene ", dim(taxa_level)[1], " asignaciones", sep=""))
    exportMat(taxa_level, file = paste0(outpath,"/",nivel, ".txt"))
  }
}
