##########
#!/usr/bin/env Rscript
#  pairwise.adonis.R
#  Copyright 2015- E. Ernestina Godoy Lozano (tinagodoy@gmail.com)
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.

### pairwise.adonis
pairwise.adonis <- function(x, factors, sim.function = 'vegdist', sim.method = 'bray', p.adjust.m = 'bonferroni') {
  # Cargar paquetes si no están disponibles
  if (!requireNamespace("vegan", quietly = TRUE)) stop("El paquete 'vegan' es requerido.")
  if (sim.function == 'daisy' && !requireNamespace("cluster", quietly = TRUE)) stop("El paquete 'cluster' es requerido.")
  
  combinaciones <- combn(unique(as.character(factors)), 2)
  pares <- F.Model <- R2 <- p.valor <- c()
  
  for (i in 1:ncol(combinaciones)) {
    niveles <- combinaciones[, i]
    subconjunto <- x[factors %in% niveles, ]
    subfactores <- factors[factors %in% niveles]
    
    distancias <- if (sim.function == 'daisy') {
      cluster::daisy(subconjunto, metric = sim.method)
    } else {
      vegan::vegdist(subconjunto, method = sim.method)
    }
    
    resultado <- vegan::adonis2(distancias ~ subfactores, permutations = 999)
    
    pares <- c(pares, paste(niveles[1], "vs", niveles[2]))
    F.Model <- c(F.Model, resultado$F[1])
    R2 <- c(R2, resultado$R2[1])
    p.valor <- c(p.valor, resultado$`Pr(>F)`[1])
  }
  
  p.ajustado <- p.adjust(p.valor, method = p.adjust.m)
  signif <- rep('', length(p.ajustado))
  signif[p.ajustado <= 0.05] <- '*'
  signif[p.ajustado <= 0.01] <- '**'
  signif[p.ajustado <= 0.001] <- '***'
  signif[p.ajustado <= 0.0001] <- '****'
  
  resultado.df <- data.frame(pares, F.Model, R2, p.valor, p.ajustado, signif)
  message("Signif. codes:  0 '****' 0.001 '***' 0.01 '**' 0.05 '*' 0.1 '+' 1")
  return(resultado.df)
}
