getVDJrarefaction_sampling <- function (VDJinput, getTable = FALSE, file = NULL, IN_vector = TRUE, 
                                        clone_group = TRUE, maintitle = "VDJ Rarefaction Curve", muestreo= 1000) {
  if (IN_vector) {
    if (is.vector(VDJinput)) {
      idiotype <- VDJinput
    }
    else {
      stop("The VDJinput is not a vector and the IN_vector parameter is TRUE")
    }
  }
  else {
    idiotype <- apply(VDJinput, 1, function(input) {
      index <- grep(TRUE, is.na(input), value = FALSE)
      input[index] <- "Unclassified"
      index <- grep(" ", input, value = FALSE)
      input[index] <- "Unclassified"
      paste(input, collapse = "|")
    })
  }
  steps <- round(log(length(idiotype), base = 10))
  if (steps < 3) {
    steps <- as.numeric(paste("1", paste(rep(0, times = steps - 
                                               1), collapse = ""), sep = "", collapse = ""))
  }
  else {
    steps <- muestreo
  }
  samplesize <- steps
  total_groups <- t(table(idiotype))
  rarefaction <- NULL
  for (i in 1:length(idiotype)) {
    if (samplesize > length(idiotype)) {
      break
    }
    rarefaction <- rbind(rarefaction, c(samplesize, rarefy(total_groups, 
                                                           samplesize)[1]))
    samplesize <- samplesize + steps
    i <- samplesize
  }
  if (getTable) {
    colnames(rarefaction) <- c("Reads_sampled", "No_clusters_captured")
    return(rarefaction)
  }
  else {
    if (!is.null(file)) 
      postscript(file = file, horizontal = FALSE, onefile = FALSE, 
                 paper = "special", width = 7, height = 7)
    if (clone_group) {
      plot(rarefaction[, 1], rarefaction[, 2], ylab = "No of Clonal Groups captured", 
           xlab = "Reads sampled", type = "o", col = "blue", 
           main = maintitle)
    }
    else {
      plot(rarefaction[, 1], rarefaction[, 2], ylab = "No. of Idiotypes captured", 
           xlab = "Reads sampled", type = "o", col = "blue", 
           main = maintitle)
    }
    if (!is.null(file)) {
      dev.off()
    }
  }
}