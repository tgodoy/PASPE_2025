#############################################################################
#########                          PASPE 2025                        ########
#########      Analisis de datos de Ciencias Genomicas usando R      ########
#########    E. Ernestina Godoy Lozano (elizabeth.godoy@insp.mx)     ########
#########                    Bitacora de comandos                    ########
#########                     UNIDAD 3. METAGENOMICA                 ########
#########                 Analisis de alfa y beta diversidad         ########
#############################################################################
# Texto sin acentos


# 1. Cargar librerias de trabajo


# 2. Cargar funciones extras


# 3. Posicionarme en mi espacio de trabajo


# 4. Cargar datos de entrada


########################################################
###       Ejercicio 1. Calculo de los estimadores     ##
###                    de alfa diversidad             ##
########################################################
# 1.1 Leer los datos de entrada abun_table y variables


# 1.2 Generar una matrix de abund_table


# 1.3 Generar matrix de taxas


# 1.4 Generar objetos necesarios phyloseq con las funciones de phyloseq especificas


# 1.4.1.Matriz de Taxas (En nuestro caso es la matriz de Generos)


# 1.4.2.Una matriz con las anotaciones de los OTUS (En nuestro caso es la anotacion taxonomica a nivel de genero)


# 1.4.3. Cargar tabla de metadatos


# 1.4.4.Construimos nuestro objeto de phyloseq


# 1.5. Obtenemos los indices de diversidad y los colocamos en una tabla


# 1.5.1 Estimemos riqueza


# 1.5.2 Estimemos diversidad con el indice de Shannon


# 1.5.3 Ahora construyamos una tabla


# 1.5.4. Redondeemos los valores


# 1.5.5 Escribimos la tabla


# 1.6 Generar boxplot de Shannon


# 1.6.1 Agregar columna de Condicion a la tabla diversity_index


# 1.6.2 usemos ggpurb::ggboxplot()


# 1.6.3 Guardemos la imagen con ggsave()


# 1.7 Generacion de un archivo de tipo phyloseq con qiime2R


# 1.7.1 Cargar librerias de trabajo


# 1.7.1 construyamos el objeto con qza_to_phyloseq()


# 1.7.2 Estimemos alfa diversidad


########################################################
###              Ejercicio 2. Rarefaccion             ##
###            Generacion de grafica de rarefaccion   ##
########################################################
# Veamos abun_table


# 2.1. Determinar un numero de muestreo fijo (secuencias). En este caso seran 1000 secuencias


# 2.2 Generemos nuestro DF con algunos muestreo, despues lo llenaremos


# 2.3 Usemos ciclo for para aplicar la funcion getVDJrarefaction_sampling()


# 2.4 Completar el muestreo correcto


# 2.5 Transformar nuestro data frame en una matrix


# 2.6 Contraer la informacion de la matriz para generar la grafica


# 2.7 Quitar valores que tienen NAs


# 2.8 Generar vectores de colores para cada muestra


# Generare 5 colores de cada paleta con la funcion colorRampPalette en formato RGB


# 2.9 Generar grafica


# 2.10 Guardar la imagen


########################################################
###  Ejercicio 3: Generacion de PCoA/NMDS con phyloseq  
########################################################
# 3.1 Generacion del PCoA con el metodo de Bray-Curtis ussando la funcion "ordinate()"


# 3.2 Podemos usar la informacion de alguna variable continua


# 3.3 Cambiarle el color a otra paleta de colores


# 3.4 Vamos a usar la sintaxis de ggplot2 para mejorar las graficas


# 3.5 Ejemplo de como generar un PCoA cuando tenemos la informacion 


# del arbol filogenetico


# 3.6 Guardar nuestro grafico


# 3.7 Ejemplo de como generar un NMDS 


########################################################
###          Ejercicio 4. Generacion de NMDS          ##
###               con matriz normalizada              ##
###        por Metagenomeseq agrupando por grupos     ##
########################################################
# Normalizar usando el metodo de metagenomeSeq. 


# 4.1. Cargar matriz de conteos absolutos


# 4.2.Transformarla a un objeto de metagenomeSeq llamado "MRexperiment"


# 4.3.Calcular el percentil para el cual sumar los conteos absolutos


# 4.4.Normalizamos la matriz 


# 4.5.Escribimos la matriz normalizada


# 4.6 Generar NMDS


# 4.6.1.Transponer la matriz normalizada para que las filas sean las muestras y los taxa las columnas


# 4.6.2.Generamos el NMDS con la funcion metaMDS de vegan con una matriz de distancia con el metodo de Bray-curtis y lo aplicamos a 2 dimensiones (k=2)


# 4.6.3.Guardamos el valor de stress en una variable


# 4.6.4.Generar grupos para el NMDS


# 4.6.5 Guardar los valores en un objeto


# 4.6.6 Generar plot


#text(nmds, labels = estaciones , cex=0.6, col= colores)


# 4.6.7 Guardar imagen


#text(nmds, labels = estaciones , cex=0.6, col= colores)


########################################################
####          Ejercicio 5. ANOSIM y ADONIS           ###
########################################################
# 5.1 ANOSIM (Diferencias entre todos los grupos)


# 5.2 ADONIS pareado (comparacion pareada de los grupos)


########################################################
###     Ejercicio 6. Principal Component Analysis     ##
########################################################
# 6.1 Cargar datos de variables


# 6.2 PCA basico


# 6.2.1 Quitar la columna de los grupos


# 6.2.2 Generar pdf con las imagenes


# 6.3 PCA mas complejo usando la funcion PCA de FactoMineR


# 6.3.1 Sin grupos


# 6.3.2 Con grupos


### Opcion para evitar sobrelape de etiquetas


# Usar la columna con los datos de los grupos


# 6.3.3 Graficar el PCA con la funcion de plot()


# 6.3.4 Usar funciones especializadas de FactoMineR


# 6.3.5 Contribuciones de las variables al componente 1 (PC1)


# 6.3.6 Contribuciones de las variables al componente 2 (PC2)


# 6.3.7 Generar imagenes en un pdf


## Listar objetos generados


## Informacion de la sesion


