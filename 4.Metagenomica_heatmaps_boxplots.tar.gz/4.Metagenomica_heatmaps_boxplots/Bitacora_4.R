##############################################################################
#########                          PASPE 2025                        #########
#########      Analisis de datos de Ciencias Genomicas usando R      #########   
#########    E. Ernestina Godoy Lozano (elizabeth.godoy@insp.mx)     #########
#########                    Bitacora de comandos                    #########
#########                     UNIDAD 3. METAGENOMICA                 #########
#########                      Heatmaps y boxplot                    #########
##############################################################################

# Texto sin acentos

# 1. Posicionarme en mi espacio de trabajo
getwd()
setwd("~/PASPE_2025_Datos_genomicos_R/4.Metagenomica_heatmaps_boxplots")
dir()

# 2.  Cargar las librerias de trabajo
suppressMessages(library(gplots))
library(ggplot2)
library(vegan)
library(reshape2)
library(metagenomeSeq)
library(Heatplus)
library(ComplexHeatmap)
library(circlize)
library(RColorBrewer)
library(tidyverse)

# 3. Leer los datos
tabla <- t(read.delim("tablas/percent_Class_more_1_perc.txt", 
                      header=T, row.names=1))
dim(tabla)
View(tabla)

#########################################################
###              Ejercicio 1. heatmap basico       ######
#########################################################

# 1.1 Generar una paleta de colores con la funcion colorRampPalette()
colors <- colorRampPalette(c("lightyellow", "dodgerblue"), space="rgb")(100)
length(colors)
head(colors)

# 1.2 Generar el heatmap con la funcion heatmap()
heatmap(tabla, Rowv=NA, Colv= NA, col= colors, margins= c(10,2))

### Ejercicio 2. Agrupaciones jerarquicas
# 2.1. Generar matriz de distancias de las muestras (filas)
mat_dist <- vegdist(tabla, method="bray")

# 2.2. Generar la clusterizacion jerarquica
row.clus <- hclust(mat_dist, "aver")

# 2.3. Integrarlo al heatmap
heatmap(tabla, Rowv=as.dendrogram(row.clus), 
        Colv= NA, col= colors, margins= c(10,3))

# 2.4. Generar la agrupacion de las columnas
mat_dist_class <- vegdist(t(tabla), method = "bray")
col.clus <- hclust(mat_dist_class, "aver")

# 2.5. Integrarlo al heatmap
heatmap(tabla, Rowv=as.dendrogram(row.clus), 
        Colv= as.dendrogram(col.clus), col= colors, margins= c(12,3))

# 2.6. Generar la figura (png)
png("figuras/heatmap_class_basico.png", width = 300*10, height = 300*6, units = "px", res=300)
heatmap(tabla, Rowv=as.dendrogram(row.clus), 
        Colv= as.dendrogram(col.clus), col= colors, margins= c(12,3))
dev.off()

#########################################################
###      Ejercicio 3. Identificacion de clusters      ###
##        Libreria gplots; funcion: heatmap.2          ##
#########################################################
# 3.1. Verefiquemos que estan los datos necesarios
View(tabla)

# 3.2. Hacer un objeto "muestras" con los nombres de las muestras
muestras <- data.frame(nombre=rownames(tabla))
head(muestras)

muestras

# 3.3. Añadir la clase 
muestras$clase <- sapply(as.character(muestras$nombre), 
                         function(x){strsplit(x, "_")[[1]][1]})

# 3.4 Añadamos colores a nuestra tabla
muestras$color <- "#A71B4BFF"
muestras$color[which(muestras$clase=="Someras")] <- "#3E8853"
muestras$color[which(muestras$clase=="Profundas")] <- "#795FAF"

# 3.5 Comencemos a armar nuestro con la funcion heatmap.2()
heatmap.2(tabla, Rowv = as.dendrogram(row.clus), 
          Colv=as.dendrogram(col.clus),
          col="cm.colors", 
          RowSideColors= muestras$color, margins=c(6,3))

dev.off()

# 3.6 Modifiquemoslo
heatmap.2(tabla, 
          Rowv = as.dendrogram(row.clus), # dendograma filas
          Colv=as.dendrogram(col.clus), # dendograma columnas
          col=colors, # Escala de colores
          RowSideColors=muestras$color, # colores de las filas
          margins=c(13,10),
          trace="none", # The distance of the line from the center of each color-cell is proportional to the size of the measuremen
          density.info = "none", # a 'density' plot, or no plot ('none') on the color-key
          key.title="Relative abundance", 
          xlab="Clase", ylab="Muestras", # Etiquetas
          main="Heatmap a nivel de Clase", 
          lhei = c(2,8)) # modificacion del tamaño del color key
legend("topright", c("Costa", "Profundas", "Someras"), # agregar leyenda
       fill=c("#A71B4BFF", "#795FAF", "#3E8853"))


# 3.7 Guardemos la imagen con la funcion png()
png("figuras/heatmap_class_complejo.png", width = 300*10, height = 300*6, units = "px", res=300)
heatmap.2(tabla, Rowv = as.dendrogram(row.clus), 
          Colv=as.dendrogram(col.clus),
          col=colors, 
          RowSideColors=muestras$color, 
          margins=c(13,10),
          trace="none", density.info = "none", 
          xlab="Clase", ylab="Muestras",
          main="Heatmap a nivel de Clase", lhei = c(2,8))
legend("bottomleft", c("Costa", "Profundas", "Someras"), 
       fill=c("#A71B4BFF", "#795FAF", "#3E8853"))
dev.off()

#########################################################
### Ejercicio 4. Agregar anotaciones de otras variables #
#########################################################

# 4.1 Carguemos nuestra tabla de variables
variables <- read.delim("tablas/abiotic_variables.txt", header=T, row.names=1)
head(variables)

# 4.2 Extraer solo algunas variables de interes (Naphthalene, Fluorene y Organic_Matter)
var_interes <- c("Naphthalene", "Fluorene", "Organic_Matter")
subtabla <- variables %>%
  select(all_of(var_interes))
head(subtabla)

# 4.3 Añadamos una clase con lo minimo
head(muestras)
muestras <- muestras %>%
  mutate(
    clase_corta = str_c(str_sub(nombre, 1, 1), 
                        str_extract(nombre, "(?<=_)S\\d+"), 
                        sep = "."))

head(tabla)

# 4.4 Cambiemos los nombres de las filas
rownames(tabla) <- muestras$clase_corta

# 4.5 Generemos nuestros colores
colors <- colorRampPalette(c("#EACDF6", "#350847"), space="rgb")(40)

# 4.6 Generemos nuestro heatmap con la funcion annHeatmap2()
plot(annHeatmap2(tabla, col=colors, breaks = 50, 
                 dendrogram = list(Row = list(dendro = as.dendrogram(row.clus)), 
                                   Col = list(dendro = as.dendrogram(col.clus))),
                 legend=3, labels=list(Col=list(nrow=12)),
                 ann=list(Row=list(data=subtabla)),
                 cluster = list(Row=list(cuth=0.25, 
                                         col=c("seagreen2", "deepskyblue", "coral1")))))
dev.off()

# 4.7 Guardemos la imagen con png()
png("figuras/heatmap_class_variables.png", width = 300*10, height = 300*6, units = "px", res=300)
plot(annHeatmap2(tabla, col = colors, breaks = 50,
                 dendrogram = list(Row = list(dendro = as.dendrogram(row.clus)), 
                                   Col = list(dendro = as.dendrogram(col.clus))),
                 legend = 3, labels = list(Col = list(nrow = 12)), 
                 ann = list(Row = list(data = subtabla)),
                 cluster = list(Row = list(cuth = 0.25, 
                                           col = c("seagreen2", "deepskyblue", "coral1")))))
dev.off()

#########################################################
####             Ejercicio 5. ComplexHeatmap         ####
#########################################################

# 5.1 Usaremos la matriz de tabla
class(tabla)
dim(tabla)

# 5.1. Heatmap simple
# Usando paletas predetermindas
Heatmap(tabla, name= "Relative abundance",
        col = rainbow(10),
        column_title = "Class > 1 %")

Heatmap(tabla, name= "Relative abundance",
        col = heat.colors(10),
        column_title = "Class > 1 %")

# 5.2. Juguemos con los colores
# Generar colores de acuerdo a los valores de la matriz
min_abu <- min(tabla)
media_abun <- mean(tabla)
max_abun <- max(tabla)
col_fun = colorRamp2(c(min_abu, media_abun, max_abun), c("seagreen2", "white", "deepskyblue"))

# 5.3 Generemos el heatmap con la funcion Heatmap()
Heatmap(tabla, name= "Relative abundance",
        col = col_fun,
        column_title = "Class > 1 %")

# 5.4 Usando categorias para cada color
# Simula una matriz binaria de presencia/ausencia (10 bacterias x 10 muestras)
genus_HC <- read.delim("tablas/genus_hidrocarburos.txt", row.names = 1)

# 5.5 Crear matriz binaria de presencia/ausencia (1 si > 0, 0 si 0)
pa_matrix <- ifelse(genus_HC > 0, 1, 0)

# 5.6 Definir colores: 0 = blanco, 1 = negro
colores <- c("0" = "gray", "1" = "black")

# 5.6 Generar heatmap
Heatmap(pa_matrix,
        name = "Presencia",
        col = colores,
        show_row_names = TRUE,
        show_column_names = TRUE,
        column_title = "Presencia/Ausencia de géneros degradadores de hidrocarburos",
        row_title = "Géneros")

# 5.7 Agreguemos anotaciones
# Verifiquemos que tenemos los datos de variables
head(variables)

# Carguemos nuestra matriz de abundancia relativa 
ClassMatrix <- read.delim("tablas/percent_Class_more_1_perc.txt", header=TRUE)

# 5.8 Anotaciones para las columnas column_ha
column_ha = HeatmapAnnotation(Taxa = ClassMatrix$Taxa.and.Samples)

Heatmap(tabla, name= "Relative abundance",
        col = col_fun,
        column_title = "Class > 1 %",
        top_annotation = column_ha)

# 5.9 Anotaciones para las filas row_ha
muestras
row_ha = rowAnnotation(Clase = muestras$clase)

Heatmap(tabla, name= "Relative abundance",
        col = col_fun,
        column_title = "Class > 1 %",
        top_annotation = column_ha,
        left_annotation = row_ha)

# 5.10 Cambio de colores especifico

ha= rowAnnotation(Clase = muestras$clase, 
                  col=list(Clase=c("Costa"= "#F2AAB5",
                                   "Someras"= "#F2E9AA",
                                   "Profundas"="#D5A3E8")))
# 5.11 Generemos el heatmap
Heatmap(tabla, name= "Relative abundance",
        col = col_fun,
        column_title = "Class > 1 %",
        top_annotation = column_ha,
        left_annotation = ha)

# 5.12 Agreguemos mas informacion de las variables
head(variables)

# 5.13 generemos la paleta de Phenanthrene
# Necesitaremos los valores min, mean y max
min_abu <- min(variables$Phenanthrene)
media_abun <- mean(variables$Phenanthrene)
max_abun <- max(variables$Phenanthrene)

# 5.14 Apliquemos esos valores con la funcion colorRamp2
col_phen = colorRamp2(c(min_abu, media_abun, max_abun), 
        c("#F1F1F1","#8B9FC7","#142D4A"))

ha_right= rowAnnotation(Phenanthrene=variables$Phenanthrene,
                        col=list(Phenanthrene=col_phen))

# 5.15 Generemos el heatmap
Heatmap(tabla, name= "Relative abundance",
        col = col_fun,
        column_title = "Class > 1 %",
        top_annotation = column_ha,
        left_annotation = ha,
        right_annotation = ha_right)

# 5.16 Agreguemos mejor una linea con la funcion anno_lines()

ha_right= rowAnnotation(Phenanthrene=variables$Phenanthrene,
                        col=list(Phenanthrene=col_phen),
                        OrganicMatter = anno_lines(variables$Organic_Matter, 
                                                   gp = gpar(col = 2), add_points = TRUE, 
                                                   pt_gp = gpar(col = 5), pch = 16))
# 5.17 Armemos el heatmap
Heatmap(tabla, name= "Relative abundance",
        col = col_fun,
        column_title = "Class > 1 %",
        top_annotation = column_ha,
        left_annotation = ha,
        right_annotation = ha_right)

# 5.18 Anotemos grupos de acuerdo a la estructura de nuestro heatmap
ha_left = rowAnnotation(Clase = anno_block(gp = gpar(fill = 2:4),
                                           labels = c("Someras", "Costa", "Profundas"), 
                                           labels_gp = gpar(col = "white", fontsize = 10)))
# 5.19 Armemos el heatmap
Heatmap(tabla, name= "Relative abundance",
        col = col_fun,
        column_title = "Class > 1 %",
        top_annotation = column_ha,
        right_annotation = ha_right,
        left_annotation = ha_left,
        row_km = 3)

# 5.20 Armemos el heatmap y Mejoremos la apariencia
ha_left = rowAnnotation(Clase = anno_block(gp = gpar(fill = c("#F2E9AA","#F2AAB5","#D5A3E8")),
                                           labels = c("Someras", "Costa", "Profundas"), 
                                           labels_gp = gpar(col = "black", fontsize = 10)))

Heatmap(tabla, name= "Relative abundance",
        col = col_fun,
        column_title = "Class > 1 %",
        top_annotation = column_ha,
        right_annotation = ha_right,
        left_annotation = ha_left,
        row_km = 3)

# 5.21 Mejoremos mas la apariencia
# Cambiemos el fontsize y la apariencie de nuestras anotaciones
column_ha = HeatmapAnnotation(Taxa = ClassMatrix$Taxa.and.Samples, 
                              annotation_name_gp = gpar(fontsize = 8))

ha_right= rowAnnotation(Phenanthrene=variables$Phenanthrene,
                        col=list(Phenanthrene=col_phen),
                        OrganicMatter = anno_lines(variables$Organic_Matter, 
                                                   gp = gpar(col = 2), add_points = TRUE, 
                                                   pt_gp = gpar(col = 5), pch = 16),
                        annotation_name_rot = 45, 
                        annotation_name_gp = gpar(fontsize = 8))

# Generemos el heatmap nuevamente
Heatmap(tabla, name= "Relative abundance",
        col = col_fun,
        column_title = "Class > 1 %",
        top_annotation = column_ha,
        right_annotation = ha_right,
        left_annotation = ha_left,
        row_km = 3,
        show_row_dend = FALSE, # quitar el dendograma de las filas
        row_names_gp = gpar(fontsize = 8), # Cambiar el tamaño de letra de las filas
        column_names_gp = gpar(fontsize = 8, fontface="italic"), # Cambiar el tamaño de letra de las columnas
        column_names_rot = 45 # Cambiar la orientacion del texto en columnas
)

# Guardemoslo con png()
png("figuras/heatmap_ComplexHeatmap.png", width = 9*300 , height = 6*300, units = "px", bg = "white", res = 300)
Heatmap(tabla, name= "Relative abundance",
        col = col_fun,
        column_title = "Class > 1 %",
        top_annotation = column_ha,
        right_annotation = ha_right,
        left_annotation = ha_left,
        row_km = 3,
        show_row_dend = FALSE, # quitar el dendograma de las filas
        row_names_gp = gpar(fontsize = 8), # Cambiar el tamaño de letra de las filas
        column_names_gp = gpar(fontsize = 8, fontface="italic"), # Cambiar el tamaño de letra de las columnas
        column_names_rot = 45 # Cambiar la orientacion del texto en columnas
)
dev.off()

#########################################################
###                Library qiime2R                    ###
###   Ejercicio 6: Leyendo y manejando artifacs en R  ###
#########################################################

# 6.1 Cargar librerias de trabajo
library(qiime2R)
library(tidyverse)

# 6.2 Leer el "artifac" que genero QIIME2 (table.qza)
tabla_qza <- read_qza("qiime2/table.qza")

# 6.3 Visualizar la estructura de nuestro objeto
str(tabla_qza)
class(tabla_qza)

# 6.4 Extraer la informacion del objeto tabla_qza como una lista
names(tabla_qza)

# 6.5 Acceder a la informacion de las features (ASVs)
View(tabla_qza$data)
head(tabla_qza$data)

# 6.7 Asociar la taxonomia
taxonomia_qza <- read_qza("qiime2/taxonomy_blast.qza")
class(taxonomia_qza)

# 6.8 Acceder a la taxonomia
View(taxonomia_qza$data)

# 6.9 Dividir en niveles taxonomicos la taxonomia usando parse_taxonomy()
taxa_sep <- parse_taxonomy(taxonomia_qza$data)
View(taxa_sep)

# 6.10 Comprimir data.frame a un nivel taxonomico en particular (Clase)
class_table <- summarize_taxa(tabla_qza$data, taxa_sep)$Class

View(class_table)

# 6.11 Grafica de barras apilada y heatmaps usando la informacion de metadata
# Cargar el archivo de metadata.tsv
metadata <- read_q2metadata("qiime2/metadata.tsv")
View(metadata)

taxa_barplot(class_table, metadata,"Zone")
taxa_heatmap(class_table, metadata,"Type")

# 6.12 Cambiar gamma de colores de acuerdo a la gramatica de ggplot2
# generar un vector de colores
n_taxa <- 11
my_color <- colorRampPalette(brewer.pal(9, "Set1"))(n_taxa)
taxa_barplot(class_table, metadata,"Zone") +
  scale_fill_manual(values=my_color) +
  theme(text = element_text(size=10), legend.position="bottom") +
  scale_y_continuous(breaks=c(0, 20, 40, 60, 80, 100)) +
  labs(fill="")

taxa_heatmap(class_table, metadata,"Type") + 
  scale_fill_gradientn(colours = terrain.colors(10))

taxa_heatmap(class_table, metadata,"Type") +
  scale_fill_gradient(low = "#77a2da", high = "#122640", na.value = NA)

# 6.13 Guardar imagen en png
png("figuras/taxa_heatmap.png", width = 10*300, height = 8*300, res = 300, pointsize = 8)
taxa_heatmap(class_table, metadata,"Type") +
  scale_fill_gradient(low = "#77a2da", high = "#122640", na.value = NA)
dev.off()


#########################################################
####                      BOXPLOTS                   ####
####     Ejercicio 7. Generacion de boxplots         ####
####                    con ggplot()                 ####
#########################################################
getwd()
setwd("~/PASPE_2025_Datos_genomicos_R/4.Metagenomica_heatmaps_boxplots")

# 7.1 Cargar librerias de trabajo
suppressMessages(library(gplots))
suppressMessages(library(ggplot2))
suppressMessages(library(vegan))
suppressMessages(library(reshape2))
suppressMessages(library(metagenomeSeq))
suppressMessages(library(Heatplus))
suppressMessages(library(RColorBrewer))
sessionInfo()

# 7.2 Cargar datos
tabla <- t(read.delim("tablas/percent_Class_more_1_perc.txt", 
                      header=T, row.names = 1))
View(tabla)
dim(tabla)

# 7.3 Escoger las taxas que me interesan
taxas <- c("Acidimicrobiia", "Betaproteobacteria", 
           "Clostridia", "Planctomycetia")

# 7.4 Generar solo una tabla con solo esas taxas
new_tabla <- tabla[,which(colnames(tabla) %in% taxas)]
head(new_tabla)
dim(new_tabla)

# 7.5 Contraer informacion para generar la grafica
melt_tabla <- melt(new_tabla)
head(melt_tabla)

# 7.6 Cambiar los nombres de las columnas
colnames(melt_tabla) <- c("Muestra", "Taxa","Freq")
head(melt_tabla)

# 7.7 Agreguemos una columna con la clase
melt_tabla$clase <- sapply(as.character(melt_tabla$Muestra), 
                           function(x){strsplit(x, "_")[[1]][1]}) 

# 7.8 usemos ggplot() y la funcion geom_boxplot()
ggplot(data=melt_tabla, aes(x=Taxa, y=Freq, fill=clase)) +
        geom_boxplot()

# 7.9 Mejoremos la apariencia, agreguemos un tema y colores distintos
ggplot(data=melt_tabla, aes(x=Taxa, y=Freq, fill=clase)) +
        geom_boxplot() +
        scale_fill_manual(values=c("coral1", "deepskyblue", "seagreen2"))+
        labs(title= "Boxplots at Class level", y= "Relative frequency (%)", x="", fill="Samples") +
        theme_bw()

ggsave("figuras/boxplot_class.png", device = "png", dpi = 300)

#########################################################
####     Ejercicio 8. Generacion de boxplots         ####
####                    con ggpurb                   ####
#########################################################

# 8.1 Cargar librerias de trabajo
library(ggpubr)

# 8.2 Usemos la funcion ggboxplot()
ggboxplot(melt_tabla, x= "Taxa", y = "Freq", 
          color = "clase", fill = "clase",
          palette = c("#FF5733", "#2782DE", "#FFC300"))

# 8.3 Añadir barras de error y muescas
ggboxplot(melt_tabla, x= "Taxa", y = "Freq", 
          color = "clase", fill = "clase",
          palette = c("#FF5733", "#2782DE", "#FFC300"),
          bxp.errorbar = TRUE, 
          notch = TRUE)

# 8.4 Cambiar las etiquetas de los ejes y añadir los puntos
ggboxplot(melt_tabla, x= "Taxa", y = "Freq", 
          color = "clase",
          palette = c("#FF5733", "#2782DE", "#FFC300"),
          bxp.errorbar = TRUE, 
          notch = FALSE, 
          xlab = "", 
          ylab= "Relative frequency (%)", 
          add = "jitter")

# 8.5 guardemos con ggsave()
ggsave("figuras/ggboxplot_class.png", device = "png", dpi = 300)

#########################################################
####     Ejercicio 9. comparaciones estadisticas     ####
####                    con ggpurb                   ####
#########################################################
# Determinar el tipo de datos con el que voy a realizar las comparaciones
# Aplicamos una prueba de normalidad y nos enfocaremos solo a un Taxa
# Shapiro-Wilk --> shapiro.test() n<=50
# Kolmogorov–Smirnov --> nortest::lillie.test() n > 50

# 9.1 Usemos shapiro.test()
length(melt_tabla$Freq[which(melt_tabla$Taxa=="Clostridia")])
shapiro.test(melt_tabla$Freq[which(melt_tabla$Taxa=="Clostridia")])

# Si el resultado de p < 0.05 los datos son No parametricos
##  2 distribuciones ---> wilcoxon.test
##  +2 distribuciones --->  Kruskal-Wallis

# Si el resultado de p > 0.05 los datos son Parametricos
##  2 distribuciones ---> t.test
##  +2 distribuciones --->  anova

# 9.2 Generar una lista con las comparaciones
mis_comparaciones <-  list(c("Costa", "Profundas"), 
                           c("Costa", "Someras"),  
                           c("Profundas", "Someras"))

# 9.3 Acomodaremos de manera diferentes los datos 
ggboxplot(melt_tabla[which(melt_tabla$Taxa=="Clostridia"),], 
          x= "clase", y = "Freq", 
          color = "clase",
          palette = c("#FF5733", "#2782DE", "#FFC300"),
          bxp.errorbar = TRUE, 
          notch = FALSE, 
          xlab = "", 
          ylab= "Relative frequency (%)", 
          title = "Clostridia",
          add = "jitter") +
  rremove("legend") +
  stat_compare_means(comparisons = mis_comparaciones, 
                     label = "p.signif",
                     method = "wilcox.test")  +
  stat_compare_means(label.y = 16, method = "kruskal.test")
ggsave("figuras/ggboxplot_class_Clostridia.png", device = "png", dpi = 300)


#########################################################
####     Ejercicio 10. Graficos para publicacion     ####
####                    con ggpurb                   ####
#########################################################
### Se generan los paneles por separado

# 10.1 Panel A: boxplot Clostridia
A <- ggboxplot(melt_tabla[which(melt_tabla$Taxa=="Clostridia"),], 
          x= "clase", y = "Freq", 
          color = "clase",
          palette = c("#FF5733", "#2782DE", "#FFC300"),
          bxp.errorbar = TRUE, 
          notch = FALSE, 
          xlab = "", 
          ylab= "Relative frequency (%)", 
          title = "Clostridia",
          add = "jitter") +
  rremove("legend") +
  stat_compare_means(comparisons = mis_comparaciones, 
                     label = "p.signif",
                     method = "wilcox.test")  +
  stat_compare_means(label.y = 16, method = "kruskal.test")

# 10.2 Panel B: boxplot Planctomycetia
B <- ggboxplot(melt_tabla[which(melt_tabla$Taxa=="Planctomycetia"),], 
          x= "clase", y = "Freq", 
          color = "clase",
          palette = c("#FF5733", "#2782DE", "#FFC300"),
          bxp.errorbar = TRUE, 
          notch = FALSE, 
          xlab = "", 
          ylab= "Relative frequency (%)", 
          title = "Planctomycetia",
          add = "jitter") +
  rremove("legend") +
  stat_compare_means(comparisons = mis_comparaciones, 
                     label = "p.signif",
                     method = "wilcox.test")  +
  stat_compare_means(label.y = 16, method = "kruskal.test")

# 10.3 Panel C: boxplot Betaproteobacteria
C <- ggboxplot(melt_tabla[which(melt_tabla$Taxa=="Betaproteobacteria"),], 
               x= "clase", y = "Freq", 
               color = "clase",
               palette = c("#FF5733", "#2782DE", "#FFC300"),
               bxp.errorbar = TRUE, 
               notch = FALSE, 
               xlab = "", 
               ylab= "Relative frequency (%)", 
               title = "Betaproteobacteria",
               add = "jitter") +
  rremove("legend") +
  stat_compare_means(comparisons = mis_comparaciones, 
                     label = "p.signif",
                     method = "wilcox.test")  +
  stat_compare_means(label.y = 16, method = "kruskal.test")

# 10.4 Generar mi arreglo de imagenes
ggarrange(A, B, C, ncol = 2, nrow = 2, labels = c("A", "B", "C"))

# 10.5 Ordenarlas mejor
BC <- ggarrange(B, C, ncol = 2, nrow = 1, labels = c("B", "C"))
ggarrange(A, BC, ncol = 1, nrow = 2, labels = c("A"))

# 10.6 Guardemos la imagen con ggsave()
ggsave("figuras/Fig1ABC.png", device= "png", height = 8, width = 12)

ls()
sessionInfo()
