##############################################################################
#########                          PASPE 2025                        #########
#########      Analisis de datos de Ciencias Genomicas usando R      #########   
#########    E. Ernestina Godoy Lozano (elizabeth.godoy@insp.mx)     #########
#########                    Bitacora de comandos                    #########
#########                     UNIDAD 3. METAGENOMICA                 #########
#########                      Heatmaps y boxplot                    #########
##############################################################################

# Texto sin acentos
# Posicionarme en mi espacio de trabajo
# 1. Cargar las librerias de trabajo


# 2. leer los datos


#########################################################
###              Ejercicio 1. heatmap basico       ######
#########################################################

# 1.1 Generar una paleta de colores con la funcion colorRampPalette()


# 1.2 Generar el heatmap con la funcion heatmap()


### Ejercicio 2. Agrupaciones jerarquicas
# 2.1. Generar matriz de distancias de las muestras (filas)


# 2.2. Generar la clusterizacion jerarquica


# 2.3. Integrarlo al heatmap


# 2.4. Generar la agrupacion de las columnas


# 2.5. Integrarlo al heatmap


# 2.6. Generar la figura (png)


#########################################################
###      Ejercicio 3. Identificacion de clusters      ###
##        Libreria gplots; funcion: heatmap.2          ##
#########################################################

# 3.1. Verefiquemos que estan los datos necesarios


# 3.2. Hacer un objeto "muestras" con los nombres de las muestras


# 3.3. Añadir la clase 


# 3.4 Añadamos colores a nuestra tabla


# 3.5 Comencemos a armar nuestro con la funcion heatmap.2()


# 3.6 Modifiquemoslo


# 3.7 Guardemos la imagen con la funcion png()


#########################################################
### Ejercicio 4. Agregar anotaciones de otras variables #
#########################################################

# 4.1 Carguemos nuestra tabla de variables


# 4.2 Extraer solo algunas variables de interes (Naphthalene, Fluorene y Organic_Matter)


# 4.3 Añadamos una clase con lo minimo


# 4.4 Cambiemos los nombres de las filas


# 4.5 Generemos nuestros colores


# 4.6 Generemos nuestro heatmap con la funcion annHeatmap2()


# 4.7 Guardemos la imagen con png()


#########################################################
####             Ejercicio 5. ComplexHeatmap         ####
#########################################################

# 5.1 Usaremos la matriz de tabla


# 5.1. Heatmap simple


# Usando paletas predetermindas


# 5.2. Juguemos con los colores


# Generar colores de acuerdo a los valores de la matriz


# 5.3 Generemos el heatmap con la funcion Heatmap()


# 5.4 Usando categorias para cada color


# Simula una matriz binaria de presencia/ausencia (10 bacterias x 10 muestras)


# 5.5 Crear matriz binaria de presencia/ausencia (1 si > 0, 0 si 0)


# 5.6 Definir colores: 0 = blanco, 1 = negro


# 5.6 Generar heatmap


# 5.7 Agreguemos anotaciones


# Verifiquemos que tenemos los datos de variables


# Carguemos nuestra matriz de abundancia relativa 


# 5.8 Anotaciones para las columnas column_ha


# 5.9 Anotaciones para las filas row_ha


# 5.10 Cambio de colores especifico


# 5.11 Generemos el heatmap


# 5.12 Agreguemos mas informacion de las variables


# 5.13 generemos la paleta de Phenanthrene


# Necesitaremos los valores min, mean y max


# 5.14 Apliquemos esos valores con la funcion colorRamp2


# 5.15 Generemos el heatmap


# 5.16 Agreguemos mejor una linea con la funcion anno_lines()


# 5.17 Armemos el heatmap


# 5.18 Anotemos grupos de acuerdo a la estructura de nuestro heatmap


# 5.19 Armemos el heatmap


# 5.20 Armemos el heatmap y Mejoremos la apariencia


# 5.21 Mejoremos mas la apariencia


# Cambiemos el fontsize y la apariencie de nuestras anotaciones


# Generemos el heatmap nuevamente


# Guardemoslo con png()


#########################################################
###                Library qiime2R                    ###
###   Ejercicio 6: Leyendo y manejando artifacs en R  ###
#########################################################

# 6.1 Cargar librerias de trabajo


# 6.2 Leer el "artifac" que genero QIIME2 (table.qza)


# 6.3 Visualizar la estructura de nuestro objeto


# 6.4 Extraer la informacion del objeto tabla_qza como una lista


# 6.5 Acceder a la informacion de las features (ASVs)


# 6.7 Asociar la taxonomia


# 6.8 Acceder a la taxonomia


# 6.9 Dividir en niveles taxonomicos la taxonomia usando parse_taxonomy()


# 6.10 Comprimir data.frame a un nivel taxonomico en particular (Clase)


# 6.11 Grafica de barras apilada y heatmaps usando la informacion de metadata


# Cargar el archivo de metadata.tsv


# 6.12 Cambiar gamma de colores de acuerdo a la gramatica de ggplot2


# generar un vector de colores


# 6.13 Guardar imagen en png


#########################################################
####                      BOXPLOTS                   ####
####     Ejercicio 7. Generacion de boxplots         ####
####                    con ggplot()                 ####
#########################################################

# 7.1 Cargar librerias de trabajo


# 7.2 Cargar datos


# 7.3 Escoger las taxas que me interesan


# 7.4 Generar solo una tabla con solo esas taxas


# 7.5 Contraer informacion para generar la grafica


# 7.6 Cambiar los nombres de las columnas


# 7.7 Agreguemos una columna con la clase


# 7.8 usemos ggplot() y la funcion geom_boxplot()


# 7.9 Mejoremos la apariencia, agreguemos un tema y colores distintos


#########################################################
####     Ejercicio 8. Generacion de boxplots         ####
####                    con ggpurb                   ####
#########################################################

# 8.1 Cargar librerias de trabajo


# 8.2 Usemos la funcion ggboxplot()


# 8.3 Añadir barras de error y muescas


# 8.4 Cambiar las etiquetas de los ejes y añadir los puntos


# 8.5 guardemos con ggsave()


#########################################################
####     Ejercicio 9. comparaciones estadisticas     ####
####                    con ggpurb                   ####
#########################################################

# Determinar el tipo de datos con el que voy a realizar las comparaciones


# Aplicamos una prueba de normalidad y nos enfocaremos solo a un Taxa
# Shapiro-Wilk --> shapiro.test() n<=50
# Kolmogorov–Smirnov --> nortest::lillie.test() n > 50

# 9.1 Usemos shapiro.test()

# Si el resultado de p < 0.05 los datos son No parametricos
##  2 distribuciones ---> wilcoxon.test
##  +2 distribuciones --->  Kruskal-Wallis
# Si el resultado de p > 0.05 los datos son Parametricos
##  2 distribuciones ---> t.test
##  +2 distribuciones --->  anova

# 9.2 Generar una lista con las comparaciones


# 9.3 Acomodaremos de manera diferentes los datos 


#########################################################
####     Ejercicio 10. Graficos para publicacion     ####
####                    con ggpurb                   ####
#########################################################

### Se generan los paneles por separado

# 10.1 Panel A: boxplot Clostridia


# 10.2 Panel B: boxplot Planctomycetia


# 10.3 Panel C: boxplot Betaproteobacteria


# 10.4 Generar mi arreglo de imagenes


# 10.5 Ordenarlas mejor


# 10.6 Guardemos la imagen con ggsave()


##### Listado de objetos

#### Informacion de la sesion